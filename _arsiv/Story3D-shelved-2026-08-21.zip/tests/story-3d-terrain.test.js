'use strict';

const assert = require('node:assert');
const { createRuntime } = require('../tools/story-sim-harness');

const runtime = createRuntime(2032);
try {
    runtime.api.newCampaign({ seed: 2032, playerStateId: 0, abundance: 1,
        doctrine: 'combined', fog: true });
    const before = runtime.api.story3DProjectionAuthorityDigest();
    const snapshot = runtime.api.story3DProjectionSnapshot({ scope: {
        id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7
    } });
    const terrain = runtime.api.story3DTerrainCompile(snapshot, { chunkSize: 16 });
    const validation = runtime.api.story3DTerrainValidate(terrain, snapshot);
    assert.strictEqual(validation.ok, true, JSON.stringify(validation.issues));
    assert.strictEqual(terrain.heightMode, 'SMOOTH_CANONICAL_INTENSITY');
    assert.strictEqual(terrain.diagnostics.instanceCount, snapshot.static.cells.length);
    assert(terrain.diagnostics.drawGroupCount > 1 && terrain.diagnostics.drawGroupCount <= 4);
    assert(terrain.diagnostics.chunkCount > 0);
    assert(terrain.groups.WATER.every(row => row.type === 'WATER' && row.height < 0.3));
    assert(terrain.groups.MOUNTAIN.every(row => row.type === 'MOUNTAIN' && row.height > 2));
    const istanbul = snapshot.static.settlements.find(row => row.name === 'İstanbul');
    assert(istanbul, 'Istanbul settlement required for Bosphorus regression');
    assert(!terrain.groups.WATER.some(row => row.cellIndex === Number(istanbul.coreCellIndex)),
        'Istanbul core must stay on land');
    assert(terrain.groups.WATER.some(row => row.cellIndex === Number(istanbul.portWaterCellIndex)),
        'Istanbul port-water cell must render as water');
    assert(terrain.diagnostics.waterMajorityCoastCount > 0);
    assert(terrain.groups.LAND.concat(terrain.groups.COAST, terrain.groups.MOUNTAIN)
        .every(row => row.naturalCover && row.naturalCover !== 'UNKNOWN'));
    assert(Object.isFrozen(terrain));
    assert(Object.isFrozen(terrain.groups));
    assert(Object.isFrozen(terrain.groups.LAND));
    assert.throws(() => terrain.groups.LAND.push({}), error => error && error.name === 'TypeError');
    const everyId = Object.values(terrain.groups).flat().map(row => row.renderId);
    assert.strictEqual(new Set(everyId).size, snapshot.static.cells.length);
    assert(everyId.every(id => terrain.identities[id]));
    assert.strictEqual(runtime.api.story3DProjectionAuthorityDigest(), before,
        'terrain compilation must not change simulation authority');
    console.log('STORY_3D_TERRAIN_OK', JSON.stringify(terrain.diagnostics));
} finally {
    runtime.dom.window.close();
}
