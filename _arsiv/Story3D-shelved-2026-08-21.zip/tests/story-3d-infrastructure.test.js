'use strict';

const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('../tools/story-sim-harness');
const { story3DSurfaceCompile } = require('../js/Story3DSurface');
const {
    story3DInfrastructureCompile, story3DInfrastructureValidate
} = require('../js/Story3DInfrastructure');

const runtime = createRuntime(2032);
try {
    runtime.api.newCampaign({ seed: 2032, playerStateId: 0, abundance: 1,
        doctrine: 'combined', fog: true });
    const snapshot = runtime.api.story3DProjectionSnapshot({ scope: {
        id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7
    } });
    const terrain = runtime.api.story3DTerrainCompile(snapshot, { chunkSize: 16 });
    const surface = story3DSurfaceCompile(terrain);
    const first = story3DInfrastructureCompile(terrain, snapshot, surface);
    const second = story3DInfrastructureCompile(terrain, snapshot, surface);
    const validation = story3DInfrastructureValidate(first, terrain, snapshot, surface);

    assert.strictEqual(validation.ok, true, JSON.stringify(validation.issues));
    assert.deepStrictEqual(first, second,
        'same canonical topology must create identical road/bridge placement');
    assert(first.diagnostics.placementCount > 0);
    assert(first.diagnostics.roadCount > 0);
    assert(first.diagnostics.bridgeCount > 0);
    assert(first.diagnostics.assetCount >= 3);
    assert(first.diagnostics.junctionCount > 0);
    assert(first.placements.every(row => row.desiredLength > 0 && row.desiredWidth > 0));
    assert(first.diagnostics.trimmedEndCount > 0);
    assert(first.placements.some(row => row.trimmedEnds > 0 && row.desiredLength < row.rawLength),
        'roads touching occupied cells must stop before the visual city core');
    assert(first.placements.every(row => Number.isFinite(row.rotationY) && Number.isFinite(row.pitch)));

    const sourceById = new Map(snapshot.static.segments.map(row => [row.renderId, row]));
    for (const placement of first.placements) {
        const source = sourceById.get(placement.sourceRenderId);
        assert(source, `missing source segment ${placement.sourceRenderId}`);
        if (placement.segmentKind !== 'JUNCTION') {
            assert.deepStrictEqual(Array.from(placement.endpointCellIndices),
                Array.from(source.endpointCellIndices));
        } else {
            assert.strictEqual(placement.endpointCellIndices[0], placement.endpointCellIndices[1]);
            assert(source.endpointCellIndices.includes(placement.endpointCellIndices[0]));
        }
    }
    for (const assetId of Object.keys(first.byAsset)) {
        assert(fs.existsSync(path.join(__dirname, '..', first.assets[assetId])),
            `missing asset ${assetId}`);
    }
    assert(Object.isFrozen(first));
    assert(Object.isFrozen(first.placements));
    assert(Object.isFrozen(first.placements[0]));

    console.log('STORY_3D_INFRASTRUCTURE_OK', JSON.stringify(first.diagnostics));
} finally {
    runtime.dom.window.close();
}
