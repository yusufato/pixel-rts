'use strict';
const assert = require('node:assert');
const { createRuntime } = require('../tools/story-sim-harness');
const { story3DSurfaceCompile, story3DSurfaceValidate, story3DSurfaceHeight } = require('../js/Story3DSurface');
const runtime = createRuntime(2032);
try {
    runtime.api.newCampaign({ seed: 2032, playerStateId: 0, abundance: 1, doctrine: 'combined', fog: true });
    const snapshot = runtime.api.story3DProjectionSnapshot({ scope: { id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7 } });
    const terrain = runtime.api.story3DTerrainCompile(snapshot, { chunkSize: 16 });
    const surface = story3DSurfaceCompile(terrain);
    assert.strictEqual(story3DSurfaceValidate(surface, terrain).ok, true);
    assert.strictEqual(surface.diagnostics.cellCount, terrain.diagnostics.instanceCount);
    assert.strictEqual(surface.diagnostics.topTriangles, terrain.diagnostics.instanceCount * 6);
    assert.strictEqual(surface.positions.length, surface.colors.length);
    assert.strictEqual(surface.landIndices.length + surface.waterIndices.length, surface.indices.length);
    assert(surface.diagnostics.landTriangles > 0);
    assert(surface.diagnostics.waterTriangles > 0);
    assert(surface.diagnostics.shoreSegments > 0);
    assert(surface.diagnostics.elevatedCellCount > 0);
    assert(surface.diagnostics.maxLandHeight > surface.diagnostics.minLandHeight);
    assert.strictEqual(Object.keys(surface.cellHeights).length, terrain.diagnostics.instanceCount);
    const sharedLandCorners = new Map();
    for (let index = 0; index < surface.positions.length; index += 3) {
        const y = surface.positions[index + 1];
        if (y <= story3DSurfaceHeight('WATER') + 0.001) continue;
        const key = `${Math.round(surface.positions[index] * 1000)}:${Math.round(surface.positions[index + 2] * 1000)}`;
        if (!sharedLandCorners.has(key)) sharedLandCorners.set(key, new Set());
        sharedLandCorners.get(key).add(y.toFixed(7));
    }
    assert([...sharedLandCorners.values()].every(heights => heights.size === 1), 'shared land corners must not open seams');
    assert.strictEqual(story3DSurfaceHeight('MOUNTAIN'), story3DSurfaceHeight('LAND'));
    assert(Object.isFrozen(surface));
    console.log('STORY_3D_SURFACE_OK', JSON.stringify(surface.diagnostics));
} finally { runtime.dom.window.close(); }
