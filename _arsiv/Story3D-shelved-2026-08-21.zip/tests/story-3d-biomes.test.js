'use strict';
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('../tools/story-sim-harness');
const { story3DBiomesCompile, story3DBiomesValidate } = require('../js/Story3DBiomes');
const { story3DSurfaceCompile } = require('../js/Story3DSurface');
const runtime = createRuntime(2032);
try {
    runtime.api.newCampaign({ seed: 2032, playerStateId: 0, abundance: 1, doctrine: 'combined', fog: true });
    const snapshot = runtime.api.story3DProjectionSnapshot({ scope: {
        id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7
    } });
    const terrain = runtime.api.story3DTerrainCompile(snapshot, { chunkSize: 16 });
    const surface = story3DSurfaceCompile(terrain);
    const first = story3DBiomesCompile(terrain, snapshot, surface);
    const second = story3DBiomesCompile(terrain, snapshot, surface);
    assert.strictEqual(story3DBiomesValidate(first, terrain, snapshot, surface).ok, true);
    assert.deepStrictEqual(first, second, 'same canonical input must create identical placements');
    assert(first.diagnostics.placementCount > 0);
    assert(first.diagnostics.forestCount > 0);
    const coverByCell = new Map(Object.values(terrain.groups).flat()
        .map(row => [row.cellIndex, row.naturalCover]));
    assert(first.placements.filter(row => row.kind === 'FOREST')
        .every(row => coverByCell.get(row.cellIndex) === 'FOREST'),
        'forest assets must be backed by canonical FOREST cover');
    assert(first.placements.some(row => row.y > 0.72));
    assert(first.placements.every(row => row.y === surface.cellHeights[row.cellRenderId]));
    const corridorCells = new Set(snapshot.static.segments
        .filter(row => row.enabled && (row.mode === 'LAND' || row.mode === 'RAIL'))
        .flatMap(row => Array.from(row.endpointCellIndices || []).map(Number)));
    assert(first.diagnostics.corridorCellCount > 0);
    assert(first.placements.every(row => !corridorCells.has(row.cellIndex)),
        'vegetation must not overlap canonical road/rail corridor cells');
    assert(Object.isFrozen(first));
    for (const assetId of Object.keys(first.byAsset)) {
        assert(fs.existsSync(path.join(__dirname, '..', first.assets[assetId])), `missing asset ${assetId}`);
    }
    console.log('STORY_3D_BIOMES_OK', JSON.stringify(first.diagnostics));
} finally { runtime.dom.window.close(); }
