'use strict';
const assert = require('node:assert');
const fs = require('node:fs');
const path = require('node:path');
const { createRuntime } = require('../tools/story-sim-harness');
const { story3DSurfaceCompile } = require('../js/Story3DSurface');
const {
    story3DSettlementTier, story3DSettlementsCompile, story3DSettlementsValidate
} = require('../js/Story3DSettlements');

const runtime = createRuntime(2032);
try {
    runtime.api.newCampaign({ seed: 2032, playerStateId: 0, abundance: 1,
        doctrine: 'combined', fog: true });
    const snapshot = runtime.api.story3DProjectionSnapshot({ scope: {
        id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7
    } });
    const terrain = runtime.api.story3DTerrainCompile(snapshot, { chunkSize: 16 });
    const surface = story3DSurfaceCompile(terrain);
    const first = story3DSettlementsCompile(terrain, snapshot, surface);
    const second = story3DSettlementsCompile(terrain, snapshot, surface);
    const validation = story3DSettlementsValidate(first, terrain, snapshot, surface);
    assert.strictEqual(validation.ok, true, JSON.stringify(validation.issues));
    assert.deepStrictEqual(first, second, 'same canonical snapshot must create identical city placement');
    assert.strictEqual(first.visualEra, 'MODERN_2010_2039');
    assert(first.diagnostics.cityCoreCount >= snapshot.static.settlements.length * 2);
    assert(first.diagnostics.cityCoreCount >= snapshot.static.settlements.length * 6);
    assert(first.diagnostics.districtCount > 0);
    assert(first.diagnostics.assetCount >= 12,
        'the visible scope must use a meaningfully varied modern asset catalog');
    assert(first.placements.every(row => row.y === surface.cellHeights[row.cellRenderId]));
    assert(story3DSettlementTier({ populationPeople: 600000, level: 1 })
        > story3DSettlementTier({ populationPeople: 20000, level: 1 }));
    for (const assetId of Object.keys(first.byAsset)) {
        assert(fs.existsSync(path.join(__dirname, '..', first.assets[assetId])), `missing asset ${assetId}`);
    }
    assert(Object.isFrozen(first));
    console.log('STORY_3D_SETTLEMENTS_OK', JSON.stringify(first.diagnostics));
} finally { runtime.dom.window.close(); }
