'use strict';

const assert = require('node:assert');
const { createRuntime } = require('../tools/story-sim-harness');

// HXD-9C.0: the renderer receives immutable copies and canonical identities.
// Trying to mutate the projection must not mutate simulation authority.
const seed = 2032;
const runtime = createRuntime(seed);
try {
    runtime.api.newCampaign({ seed, playerStateId: 0, abundance: 1,
        doctrine: 'combined', fog: true });
    const options = { scope: { id: 'MARMARA_ANKARA',
        nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7 } };
    const world = runtime.api.hexWorldEnsure();
    const beforeCenter = Number(world.centerX[0]);
    const beforeDigest = runtime.api.story3DProjectionAuthorityDigest();
    const first = runtime.api.story3DProjectionSnapshot(options);
    const validation = runtime.api.story3DProjectionValidate(first);
    assert.strictEqual(validation.ok, true, JSON.stringify(validation.issues));
    assert.strictEqual(first.rendererAuthority, 'READ_ONLY');
    assert(Object.isFrozen(first));
    assert(Object.isFrozen(first.static));
    assert(Object.isFrozen(first.static.cells));
    assert(Object.isFrozen(first.static.cells[0]));
    assert(first.static.cells.length > 0);
    assert(first.static.cells.length < first.static.world.totalCellCount,
        'decision prototype must project the corridor, not duplicate the whole world');
    assert(first.static.settlements.some(row => row.name === 'Ankara'));
    assert(first.static.settlements.some(row => row.name === 'İstanbul'));
    assert(first.static.settlements.every(row => Number.isFinite(row.populationPeople)));
    assert(first.static.districts.every(row => Number.isFinite(row.populationPeople)));

    const ankara = first.static.settlements.find(row => row.name === 'Ankara');
    const identity = runtime.api.story3DProjectionResolveIdentity(first, ankara.renderId);
    assert(identity);
    assert.strictEqual(identity.kind, 'CITY');
    assert.strictEqual(identity.nodeId, ankara.nodeId);
    assert.strictEqual(identity.regionId, `region:${ankara.nodeId}`);

    assert.throws(() => { first.static.cells[0].x = 999999; },
        error => error && error.name === 'TypeError');
    assert.throws(() => { first.static.cells.push({}); },
        error => error && error.name === 'TypeError');
    assert.strictEqual(Number(runtime.api.hexWorldEnsure().centerX[0]), beforeCenter);
    assert.strictEqual(runtime.api.story3DProjectionAuthorityDigest(), beforeDigest,
        'projection mutation attempt must leave simulation authority unchanged');

    const second = runtime.api.story3DProjectionSnapshot(options);
    assert.strictEqual(second.static, first.static,
        'unchanged topology must reuse the immutable static snapshot');
    assert.notStrictEqual(second.dynamic, first.dynamic,
        'dynamic render state is sampled separately from static topology');

    const story = runtime.api.state();
    const source = story.nodes.find(node => node.name === 'Ankara');
    const target = story.nodes.find(node => node.name === 'İstanbul');
    assert(source && target && source.owner === target.owner);
    const created = runtime.api.tradeCreateOrder({
        sourceRegionId: `region:${source.id}`, targetRegionId: `region:${target.id}`,
        resourceId: 'food', quantity: 1, priority: 100,
        transportMode: 'LAND', exportReserveBps: 0,
        source: 'HXD9C0_PROJECTION_FIXTURE'
    });
    assert.strictEqual(created.ok, true);
    const dispatched = runtime.api.tradeDispatchOrder(created.order.id, 1);
    assert.strictEqual(dispatched.ok, true, JSON.stringify(dispatched));
    const withAgent = runtime.api.story3DProjectionSnapshot(options);
    assert.strictEqual(withAgent.static, first.static,
        'shipment creation must not rebuild static terrain/city topology');
    assert.strictEqual(withAgent.dynamic.agents.length, 1);
    const agent = withAgent.dynamic.agents[0];
    assert.strictEqual(agent.shipmentId, dispatched.shipment.id);
    assert.strictEqual(agent.vehicleClass, 'ROAD_CONVOY');
    const agentIdentity = runtime.api.story3DProjectionResolveIdentity(
        withAgent, agent.renderId);
    assert.strictEqual(agentIdentity.kind, 'TRANSPORT_AGENT');
    assert.strictEqual(agentIdentity.shipmentId, dispatched.shipment.id);
    assert.strictEqual(runtime.api.story3DProjectionValidate(withAgent).ok, true);

    const segment = withAgent.static.segments.find(row => row.enabled);
    assert(segment, 'prototype scope must contain a mutable physical segment');
    assert.strictEqual(runtime.api.hexInfrastructureSetSegmentDamage(
        segment.segmentId, 2500, { reason: 'HXD9C0_AUTHORIZED_DAMAGE' }).ok, true);
    const afterDamage = runtime.api.story3DProjectionSnapshot(options);
    assert.notStrictEqual(afterDamage.static, first.static,
        'authorized topology state change must invalidate the static projection');
    const damagedProjection = afterDamage.static.segments.find(
        row => row.segmentId === segment.segmentId);
    assert(damagedProjection);
    assert.strictEqual(damagedProjection.damageBps, 2500);
    assert.strictEqual(runtime.api.story3DProjectionResolveIdentity(
        afterDamage, damagedProjection.renderId).segmentId, segment.segmentId);
    assert.strictEqual(runtime.api.story3DProjectionValidate(afterDamage).ok, true);

    console.log('STORY_3D_PROJECTION_OK', JSON.stringify({
        projectionHash: withAgent.projectionHash,
        staticHash: withAgent.static.staticHash,
        cells: withAgent.static.cells.length,
        cities: withAgent.static.settlements.length,
        districts: withAgent.static.districts.length,
        sites: withAgent.static.sites.length,
        segments: withAgent.static.segments.length,
        agents: withAgent.dynamic.agents.length,
        targetedStaticInvalidation: true,
        immutable: true,
        authorityUnchanged: true
    }));
} finally {
    runtime.dom.window.close();
}
