'use strict';

const assert = require('assert');
const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');
const pkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const lock = JSON.parse(fs.readFileSync(path.join(root, 'package-lock.json'), 'utf8'));
const main = fs.readFileSync(path.join(root, 'electron', 'main.js'), 'utf8');
const preload = fs.readFileSync(path.join(root, 'electron', 'preload.js'), 'utf8');
const html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
const bootstrap = fs.readFileSync(path.join(root, 'js', 'Story3DBootstrap.mjs'), 'utf8');

assert.strictEqual(pkg.dependencies.three, '0.185.1', 'Three.js tam sürüme kilitlenmeli');
assert.strictEqual(lock.packages['node_modules/three'].version, '0.185.1', 'lock ve package sürümü eşleşmeli');
assert(main.includes("additionalArguments: [`--pixel-story-renderer=${STORY_RENDERER_MODE}`]"), 'ana süreç renderer modunu preload\'a aktarmalı');
assert(preload.includes('requestedStoryRenderer'), 'preload salt-okunur renderer tercihini açmalı');
assert(html.includes('<script type="module" src="js/Story3DBootstrap.mjs"></script>'), '3D bootstrap modülü yüklenmeli');
assert(html.includes('<script src="js/Story3DSurface.js"></script>'), 'sürekli arazi yüzeyi derleyicisi bootstrap öncesi yüklenmeli');
assert(html.includes('<script src="js/Story3DBiomes.js"></script>'), 'biyom yerleşim derleyicisi bootstrap öncesi yüklenmeli');
assert(html.includes('<script src="js/Story3DSettlements.js"></script>'), 'şehir/ilçe derleyicisi bootstrap öncesi yüklenmeli');
assert(html.includes('<script src="js/Story3DInfrastructure.js"></script>'), 'yol/köprü derleyicisi bootstrap öncesi yüklenmeli');
assert(html.includes('type="importmap"'), 'GLTFLoader yerel Three modülünü import map ile çözmeli');
assert(html.includes("'sha256-3n1ASHUKRvZ05lq7Rb9knBmOcLhVo3SepAyh/ROlhwA='"), 'import map CSP içinde yalnız kendi içerik karmasıyla açılmalı');
assert(bootstrap.includes("await import(THREE_MODULE_PATH)"), 'Three.js yalnız 3D istendiğinde dinamik yüklenmeli');
assert(bootstrap.includes("'../node_modules/three/build/three.module.js'"), 'yerel/offline Three.js kullanılmalı');
assert(bootstrap.includes("canvas.getContext('webgl2'"), 'WebGL2 açıkça sınanmalı');
assert(bootstrap.includes('webglcontextlost'), 'context loss geri dönüşü bulunmalı');
assert(bootstrap.includes("state.requested !== '3d'"), '3D açık tercih olmadan başlamamalı');
assert(bootstrap.includes("document.body.removeAttribute('data-story-renderer')"), 'hata halinde 2D görünümü geri gelmeli');
assert(!bootstrap.includes('localStorage'), 'renderer seçimi save/localStorage durumuna sızmamalı');
assert(bootstrap.includes("landSurface.name = 'TerrainContinuousSurface'"), 'görünen arazi ayrı hex sütunları değil tek yüzey olmalı');
assert(bootstrap.includes("waterSurface.name = 'TerrainWaterSurface'"), 'su ayrı fiziksel materyal katmanında kalmalı');
assert(bootstrap.includes('polyhaven-aerial-grass-rock'), 'lisanslı arazi dokusu yerel paketten yüklenmeli');
assert(bootstrap.includes("geometry.setAttribute('uv'"), 'arazi dokusu dünya-uzayı UV koordinatı almalı');
assert(bootstrap.includes('new THREE.InstancedMesh(node.geometry, node.material, placements.length)'), 'biyom modelleri tek tek draw call üretmemeli');
assert(bootstrap.includes('installWorldAssetLayers'), 'biyom ve yerleşim yüklemesi tek hazır kapısında birleşmeli');
assert(bootstrap.includes('installInfrastructureLayer'), 'kanonik yol ve köprüler ayrı 3D katmanda kurulmalı');
assert(bootstrap.includes('installCityLabels'), 'şehir adı ve nüfus etiketi 3D konuma bağlanmalı');
assert(bootstrap.includes('setViewScale(scale)'), 'uzak/orta/yakın görsel kabul ölçeği denetlenebilmeli');

console.log('STORY_3D_BOOTSTRAP_CONTRACT_OK', JSON.stringify({
    three: pkg.dependencies.three,
    defaultRenderer: '2d',
    explicitRenderer: '3d',
    webgl2Required: true,
    contextLossFallback: true,
}));
