'use strict';

// HXD-9C.2b — canonical hex plan -> continuous-looking renderer surface.
// The hex grid remains simulation authority; visible terrain is a render product.
const STORY_3D_SURFACE_SCHEMA_VERSION = 2;
const DIRECTIONS = Object.freeze([[1, 0], [1, -1], [0, -1], [-1, 0], [-1, 1], [0, 1]].map(Object.freeze));
const EDGE_CORNERS = Object.freeze([[0, 1], [5, 0], [4, 5], [3, 4], [2, 3], [1, 2]].map(Object.freeze));
const COLORS = Object.freeze({
    WATER: [0.045, 0.23, 0.39], LAND: [0.22, 0.40, 0.18],
    COAST: [0.38, 0.50, 0.23], MOUNTAIN: [0.34, 0.38, 0.25],
    OPEN_LAND: [0.29, 0.48, 0.21], FOREST: [0.12, 0.31, 0.13],
    DRYLAND: [0.52, 0.45, 0.25],
    SHORE_TOP: [0.72, 0.61, 0.34], SHORE_BOTTOM: [0.10, 0.27, 0.31]
});
const LAND_BASE_HEIGHT = 0.72;
const WATER_HEIGHT = 0.18;
const ELEVATION_AMPLITUDE = 2.1;

function story3DSurfaceHeight(type) { return type === 'WATER' ? WATER_HEIGHT : LAND_BASE_HEIGHT; }
function story3DSurfaceCellHeight(row) {
    if (row.type === 'WATER') return WATER_HEIGHT;
    let intensity = Math.max(0, Math.min(1, (Number(row.mountainIntensityBps) || 0) / 10000));
    if (row.type === 'MOUNTAIN') intensity = Math.max(0.45, intensity);
    return LAND_BASE_HEIGHT + Math.pow(intensity, 1.25) * ELEVATION_AMPLITUDE;
}
function colorFor(type, naturalCover, x, z, height) {
    // Continuous world-space variation: adjacent cells sample the same field at
    // their shared corners, so biome color no longer exposes the logical grid.
    const visualType = type === 'WATER' ? 'WATER'
        : type === 'COAST' ? 'COAST'
            : (naturalCover === 'FOREST' || naturalCover === 'DRYLAND'
                || naturalCover === 'OPEN_LAND' || naturalCover === 'MOUNTAIN')
                ? naturalCover : type;
    const source = COLORS[visualType] || COLORS.LAND;
    const field = Math.sin(x * 0.19 + z * 0.11) * 0.52
        + Math.sin(x * 0.071 - z * 0.163) * 0.31
        + Math.sin((x + z) * 0.037) * 0.17;
    const shift = field * (visualType === 'WATER' ? 0.018 : 0.065);
    const elevation = visualType === 'WATER' ? 0
        : Math.max(0, Math.min(1, ((Number(height) || LAND_BASE_HEIGHT) - LAND_BASE_HEIGHT) / ELEVATION_AMPLITUDE));
    return source.map((value, channel) => {
        const highland = COLORS.MOUNTAIN[channel];
        const tinted = value + shift + (highland - value) * elevation * 0.72;
        return Math.max(0, Math.min(1, tinted));
    });
}
function cornerOf(row, corner, radius, height) {
    const angle = Math.PI / 180 * (60 * corner - 30);
    return [row.x + radius * Math.cos(angle), height, row.z + radius * Math.sin(angle)];
}
function cornerKey(row, corner, radius) {
    const angle = Math.PI / 180 * (60 * corner - 30);
    const x = row.x + radius * Math.cos(angle), z = row.z + radius * Math.sin(angle);
    // Canonical centers are Float32 world coordinates. Millimetric renderer
    // quantisation merges the same topological corner despite that source
    // precision, preventing elevated neighbours from opening visible seams.
    return `${Math.round(x * 1000)}:${Math.round(z * 1000)}`;
}

function story3DSurfaceCompile(plan) {
    if (!plan || plan.rendererAuthority !== 'READ_ONLY' || !plan.groups) throw new Error('STORY_3D_SURFACE_TERRAIN_PLAN_REQUIRED');
    const rows = ['WATER', 'LAND', 'COAST', 'MOUNTAIN'].flatMap(type => plan.groups[type]);
    const byAxial = new Map(rows.map(row => [`${row.q}:${row.r}`, row]));
    const cellHeights = {};
    const cornerSamples = new Map();
    for (const row of rows) {
        const height = story3DSurfaceCellHeight(row);
        cellHeights[row.renderId] = height;
        if (row.type === 'WATER') continue;
        for (let corner = 0; corner < 6; corner++) {
            const key = cornerKey(row, corner, 1);
            const sample = cornerSamples.get(key) || { total: 0, count: 0 };
            sample.total += height; sample.count++;
            cornerSamples.set(key, sample);
        }
    }
    function sharedCornerHeight(row, corner) {
        if (row.type === 'WATER') return WATER_HEIGHT;
        const sample = cornerSamples.get(cornerKey(row, corner, 1));
        return sample ? sample.total / sample.count : cellHeights[row.renderId];
    }
    const positions = [], colors = [], indices = [], landIndices = [], waterIndices = [], cellRanges = [];
    const shorePositions = [], shoreColors = [], shoreIndices = [];
    for (const row of rows) {
        const vertexStart = positions.length / 3;
        positions.push(row.x, cellHeights[row.renderId], row.z);
        colors.push(...colorFor(row.type, row.naturalCover, row.x, row.z, cellHeights[row.renderId]));
        for (let corner = 0; corner < 6; corner++) {
            const vertex = cornerOf(row, corner, 1, sharedCornerHeight(row, corner));
            positions.push(...vertex);
            colors.push(...colorFor(row.type, row.naturalCover, vertex[0], vertex[2], vertex[1]));
        }
        const indexStart = indices.length;
        const materialIndices = row.type === 'WATER' ? waterIndices : landIndices;
        for (let corner = 0; corner < 6; corner++) {
            const triangle = [vertexStart, vertexStart + 1 + corner, vertexStart + 1 + ((corner + 1) % 6)];
            indices.push(...triangle);
            materialIndices.push(...triangle);
        }
        cellRanges.push(Object.freeze({ renderId: row.renderId, indexStart, indexCount: 18 }));
        if (row.type === 'WATER') continue;
        for (let direction = 0; direction < 6; direction++) {
            const delta = DIRECTIONS[direction];
            const neighbor = byAxial.get(`${row.q + delta[0]}:${row.r + delta[1]}`);
            const markedCoast = Boolean(row.coastEdgeMask & (1 << direction));
            if (neighbor?.type !== 'WATER' && !markedCoast) continue;
            if (!neighbor && !markedCoast) continue;
            const pair = EDGE_CORNERS[direction];
            const a = cornerOf(row, pair[0], 1, sharedCornerHeight(row, pair[0]));
            const b = cornerOf(row, pair[1], 1, sharedCornerHeight(row, pair[1]));
            const start = shorePositions.length / 3;
            shorePositions.push(a[0], a[1], a[2], b[0], b[1], b[2], b[0], 0.16, b[2], a[0], 0.16, a[2]);
            shoreColors.push(...COLORS.SHORE_TOP, ...COLORS.SHORE_TOP, ...COLORS.SHORE_BOTTOM, ...COLORS.SHORE_BOTTOM);
            shoreIndices.push(start, start + 1, start + 2, start, start + 2, start + 3);
        }
    }
    const landHeights = rows.filter(row => row.type !== 'WATER').map(row => cellHeights[row.renderId]);
    return Object.freeze({ schemaVersion: STORY_3D_SURFACE_SCHEMA_VERSION, sourceStaticHash: plan.sourceStaticHash,
        positions: Object.freeze(positions), colors: Object.freeze(colors), indices: Object.freeze(indices),
        landIndices: Object.freeze(landIndices), waterIndices: Object.freeze(waterIndices),
        shorePositions: Object.freeze(shorePositions), shoreColors: Object.freeze(shoreColors), shoreIndices: Object.freeze(shoreIndices),
        cellRanges: Object.freeze(cellRanges), cellHeights: Object.freeze(cellHeights), diagnostics: Object.freeze({ cellCount: rows.length,
            topTriangles: indices.length / 3, landTriangles: landIndices.length / 3,
            waterTriangles: waterIndices.length / 3, shoreSegments: shoreIndices.length / 6,
            drawCalls: shoreIndices.length ? 3 : 2,
            minLandHeight: landHeights.length ? Math.min(...landHeights) : LAND_BASE_HEIGHT,
            maxLandHeight: landHeights.length ? Math.max(...landHeights) : LAND_BASE_HEIGHT,
            elevatedCellCount: landHeights.filter(height => height > LAND_BASE_HEIGHT + 0.001).length }) });
}
function story3DSurfaceValidate(surface, plan) {
    const issues = [];
    if (!surface || surface.schemaVersion !== STORY_3D_SURFACE_SCHEMA_VERSION) issues.push('SCHEMA');
    if (surface && plan && surface.sourceStaticHash !== plan.sourceStaticHash) issues.push('SOURCE_HASH');
    if (surface && plan && surface.diagnostics.cellCount !== plan.diagnostics.instanceCount) issues.push('CELL_PARITY');
    if (surface && surface.positions.length !== surface.colors.length) issues.push('TOP_COLOR_PARITY');
    if (surface && surface.landIndices.length + surface.waterIndices.length !== surface.indices.length) issues.push('MATERIAL_INDEX_PARITY');
    if (surface && surface.shorePositions.length !== surface.shoreColors.length) issues.push('SHORE_COLOR_PARITY');
    if (surface && plan && Object.keys(surface.cellHeights || {}).length !== plan.diagnostics.instanceCount) issues.push('HEIGHT_PARITY');
    return Object.freeze({ ok: issues.length === 0, issues: Object.freeze(issues) });
}
if (typeof window !== 'undefined') { window.story3DSurfaceCompile = story3DSurfaceCompile; window.story3DSurfaceValidate = story3DSurfaceValidate; }
if (typeof module !== 'undefined' && module.exports) module.exports = { STORY_3D_SURFACE_SCHEMA_VERSION, story3DSurfaceHeight, story3DSurfaceCellHeight, story3DSurfaceCompile, story3DSurfaceValidate };
