'use strict';

// HXD-9C.0 — renderer authority boundary.
// This module projects canonical simulation ledgers into immutable plain data.
// It owns no game truth and exposes no mutation callback to a renderer.

const STORY_3D_PROJECTION_SCHEMA_VERSION = 2;
const STORY_3D_PROJECTION_ADAPTER_VERSION = 'story-3d-projection-2';
const STORY_3D_PROJECTION_DEFAULT_SCOPE = Object.freeze({
    id: 'MARMARA_ANKARA', nodeNames: ['İstanbul', 'Bursa', 'Ankara'], marginRadii: 7
});
let STORY_3D_PROJECTION_STATIC_CACHE = null;

function story3DProjectionHash(value) {
    const text = typeof value === 'string' ? value : JSON.stringify(value);
    return typeof storyHexWorldHashText === 'function'
        ? storyHexWorldHashText(text)
        : 'projection:' + text.length + ':' + text.slice(0, 32);
}

function story3DProjectionFreeze(value, seen) {
    if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value;
    const visited = seen || new Set();
    if (visited.has(value)) return value;
    visited.add(value);
    for (const key of Object.keys(value)) story3DProjectionFreeze(value[key], visited);
    return Object.freeze(value);
}

function story3DProjectionScope(options, world, settlements) {
    const requested = options && options.scope || STORY_3D_PROJECTION_DEFAULT_SCOPE;
    if (requested === 'FULL_WORLD' || requested && requested.id === 'FULL_WORLD') {
        return story3DProjectionFreeze({ id: 'FULL_WORLD', nodeNames: [],
            marginRadii: 0, minX: 0, minY: 0,
            maxX: Number(world.width), maxY: Number(world.height) });
    }
    const nodeNames = Array.isArray(requested.nodeNames) && requested.nodeNames.length
        ? requested.nodeNames.map(String) : STORY_3D_PROJECTION_DEFAULT_SCOPE.nodeNames.slice();
    const nameSet = new Set(nodeNames);
    const anchors = (STORY.nodes || []).filter(node => nameSet.has(String(node.name)))
        .map(node => Number(settlements.coreCellIndices[Number(node.id)]))
        .filter(index => Number.isInteger(index) && index >= 0 && index < world.cellCount);
    if (!anchors.length) throw new Error('STORY_3D_SCOPE_ANCHOR_MISSING');
    const marginRadii = Math.max(0, Number(requested.marginRadii == null
        ? STORY_3D_PROJECTION_DEFAULT_SCOPE.marginRadii : requested.marginRadii));
    const margin = Number(world.radius) * marginRadii;
    const xs = anchors.map(index => Number(world.centerX[index]));
    const ys = anchors.map(index => Number(world.centerY[index]));
    return story3DProjectionFreeze({
        id: String(requested.id || 'CUSTOM'), nodeNames, marginRadii,
        minX: Math.max(0, Math.min(...xs) - margin),
        minY: Math.max(0, Math.min(...ys) - margin),
        maxX: Math.min(Number(world.width), Math.max(...xs) + margin),
        maxY: Math.min(Number(world.height), Math.max(...ys) + margin)
    });
}

function story3DProjectionScopeIncludes(scope, x, y) {
    return Number(x) >= scope.minX && Number(x) <= scope.maxX
        && Number(y) >= scope.minY && Number(y) <= scope.maxY;
}

function story3DProjectionCellId(world, index) {
    const q = Number(world.qValues[index]);
    const r = Number(world.rValues[index]);
    return typeof storyHexWorldId === 'function' ? storyHexWorldId(q, r) : `hex:${q}:${r}`;
}

function story3DProjectionMapEntity(kind, values) {
    return Object.assign({ kind: String(kind) }, values || {});
}

function story3DProjectionStaticSource() {
    const world = storyHexWorldEnsure();
    const geography = storyHexGeographyEnsure();
    const regions = storyHexRegionsEnsure();
    const political = storyHexPoliticalViewEnsure();
    const settlements = storyHexSettlementsEnsure();
    const urban = storyHexUrbanFootprintsEnsure();
    const sites = storyHexSitesEnsure();
    const infrastructure = storyHexInfrastructureSegmentsEnsure();
    const natural = typeof storyHexNaturalResourcesEnsure === 'function'
        ? storyHexNaturalResourcesEnsure() : null;
    return { world, geography, regions, political, settlements, urban, sites, infrastructure, natural };
}

function story3DProjectionSourceKey(source, scope) {
    return story3DProjectionHash([
        STORY_3D_PROJECTION_ADAPTER_VERSION, scope.id, scope.minX, scope.minY,
        scope.maxX, scope.maxY, source.world.layoutHash,
        source.geography.geographyHash, source.regions.membershipHash,
        source.political.sourceHash, source.settlements.settlementHash,
        source.urban.sourceHash, source.sites.registryHash,
        source.infrastructure.topologyHash, source.infrastructure.revision,
        source.natural?.registryHash || '-'
    ]);
}

function story3DProjectionStaticSnapshot(options) {
    const source = story3DProjectionStaticSource();
    const scope = story3DProjectionScope(options || {}, source.world, source.settlements);
    const sourceKey = story3DProjectionSourceKey(source, scope);
    if (STORY_3D_PROJECTION_STATIC_CACHE
        && STORY_3D_PROJECTION_STATIC_CACHE.sourceKey === sourceKey) {
        return STORY_3D_PROJECTION_STATIC_CACHE.snapshot;
    }
    const selected = [];
    const selectedSet = new Set();
    const cells = [];
    const identities = {};
    for (let index = 0; index < source.world.cellCount; index++) {
        const x = Number(source.world.centerX[index]);
        const y = Number(source.world.centerY[index]);
        if (!story3DProjectionScopeIncludes(scope, x, y)) continue;
        selected.push(index);
        selectedSet.add(index);
        const cellId = story3DProjectionCellId(source.world, index);
        const regionNumber = Number(source.regions.cellRegionIds[index]);
        const regionId = regionNumber >= 0 ? `region:${regionNumber}` : null;
        const renderId = `cell:${cellId}`;
        const mapEntity = story3DProjectionMapEntity('HEX_CELL', {
            cellId, cellIndex: index, regionId
        });
        identities[renderId] = mapEntity;
        const naturalCoverCode = source.natural ? Number(source.natural.coverCodes[index]) : -1;
        const naturalCoverNames = typeof STORY_HEX_NATURAL_COVER_NAMES !== 'undefined'
            ? STORY_HEX_NATURAL_COVER_NAMES
            : ['WATER', 'COAST', 'OPEN_LAND', 'FOREST', 'MOUNTAIN', 'DRYLAND'];
        cells.push({ renderId, cellId, cellIndex: index,
            q: Number(source.world.qValues[index]), r: Number(source.world.rValues[index]),
            x, y, terrainClass: Number(source.geography.terrainClass[index]),
            landCoverageBps: Number(source.geography.landCoverageBps[index]),
            mountainIntensityBps: Number(source.geography.mountainIntensityBps[index]),
            riverPresence: Number(source.geography.riverPresence[index]),
            movementMask: Number(source.geography.movementMask[index]),
            coastEdgeMask: Number(source.geography.coastEdgeMask[index]),
            naturalCoverCode,
            naturalCover: String(naturalCoverNames[naturalCoverCode] || 'UNKNOWN'),
            resourceCode: source.natural ? Number(source.natural.resourceCodes[index]) : 0,
            arableSuitabilityBps: source.natural
                ? Number(source.natural.arableSuitabilityBps[index]) : 0,
            forestrySuitabilityBps: source.natural
                ? Number(source.natural.forestrySuitabilityBps[index]) : 0,
            regionId, ownerId: Number(source.political.cellOwnerIds[index]), mapEntity });
    }
    const urbanByCity = new Map((source.urban.records || []).map(record => [Number(record.cityId), record]));
    const settlements = [];
    for (const node of STORY.nodes || []) {
        const nodeId = Number(node.id);
        const coreCellIndex = Number(source.settlements.coreCellIndices[nodeId]);
        if (!selectedSet.has(coreCellIndex)) continue;
        const renderId = `city:${nodeId}`;
        const mapEntity = story3DProjectionMapEntity('CITY', {
            nodeId, regionId: `region:${nodeId}`
        });
        identities[renderId] = mapEntity;
        const urbanRecord = urbanByCity.get(nodeId);
        settlements.push({ renderId, nodeId, regionId: `region:${nodeId}`,
            name: String(node.name || nodeId), ownerId: Number(node.owner),
            level: Math.max(1, Number(node.level) || 1), coreCellIndex,
            populationPeople: Math.max(0, Number(urbanRecord?.populationPeople) || 0),
            wealth: Math.max(0, Number(urbanRecord?.wealth) || Number(node.wealth) || 0),
            port: Number(source.settlements.portFlags[nodeId]) === 1,
            portLandCellIndex: Number(source.settlements.portLandCellIndices[nodeId]),
            portWaterCellIndex: Number(source.settlements.portWaterCellIndices[nodeId]),
            mapEntity });
    }
    const districts = [];
    for (const record of source.urban.records || []) {
        for (let slot = 0; slot < (record.districts || []).length; slot++) {
            const district = record.districts[slot];
            if (!selectedSet.has(Number(district.index))) continue;
            const cellId = story3DProjectionCellId(source.world, Number(district.index));
            const renderId = `district:${record.cityId}:${slot}`;
            const mapEntity = story3DProjectionMapEntity('DISTRICT', {
                nodeId: Number(record.cityId), regionId: `region:${record.cityId}`,
                cellId, cellIndex: Number(district.index), districtSlot: slot
            });
            identities[renderId] = mapEntity;
            districts.push({ renderId, nodeId: Number(record.cityId),
                regionId: `region:${record.cityId}`, cellId,
                cellIndex: Number(district.index), kind: String(district.kind),
                kindCode: Number(district.kindCode),
                ownerId: Number(STORY.nodes?.[Number(record.cityId)]?.owner),
                level: Math.max(1, Number(STORY.nodes?.[Number(record.cityId)]?.level) || 1),
                populationPeople: Math.max(0, Number(record.populationPeople) || 0),
                wealth: Math.max(0, Number(record.wealth) || 0), mapEntity });
        }
    }
    const sites = [];
    for (const site of source.sites.sites || []) {
        if (!selectedSet.has(Number(site.cellIndex))) continue;
        const renderId = `site:${site.id}`;
        const mapEntity = story3DProjectionMapEntity('SITE', {
            siteId: String(site.id), nodeId: Number(site.cityId),
            regionId: String(site.regionId), cellId: String(site.cellId)
        });
        identities[renderId] = mapEntity;
        sites.push({ renderId, siteId: String(site.id), cellId: String(site.cellId),
            cellIndex: Number(site.cellIndex), regionId: String(site.regionId),
            nodeId: Number(site.cityId), siteType: String(site.siteType),
            sectorId: site.sectorId == null ? null : String(site.sectorId),
            ownerCompanyId: site.ownerCompanyId == null ? null : String(site.ownerCompanyId),
            installedVisualStage: Number(site.installedVisualStage) || 0,
            lifecycleState: String(site.lifecycleState || 'UNKNOWN'),
            constructionState: String(site.constructionState || 'NONE'),
            capacity: Math.max(0, Number(site.capacity) || 0), mapEntity });
    }
    const segments = [];
    for (const segment of source.infrastructure.segments || []) {
        const endpoints = (segment.endpointCellIndices || []).map(Number);
        if (!endpoints.some(index => selectedSet.has(index))) continue;
        const renderId = `segment:${segment.id}`;
        const mapEntity = story3DProjectionMapEntity('INFRASTRUCTURE_SEGMENT', {
            segmentId: String(segment.id), corridorIds: (segment.corridorIds || []).map(String)
        });
        identities[renderId] = mapEntity;
        segments.push({ renderId, segmentId: String(segment.id),
            mode: String(segment.mode), segmentKind: String(segment.kind),
            endpointCellIndices: endpoints,
            corridorIds: (segment.corridorIds || []).map(String),
            enabled: segment.enabled === true,
            lifecycleState: String(segment.lifecycleState || 'UNKNOWN'),
            maintenanceBps: Number(segment.maintenanceBps) || 0,
            damageBps: Number(segment.damageBps) || 0,
            baseCapacity: Math.max(0, Number(segment.baseCapacity) || 0), mapEntity });
    }
    const payload = {
        schemaVersion: STORY_3D_PROJECTION_SCHEMA_VERSION,
        adapterVersion: STORY_3D_PROJECTION_ADAPTER_VERSION,
        sourceKey, scope,
        source: { worldLayoutHash: source.world.layoutHash,
            geographyHash: source.geography.geographyHash,
            regionMembershipHash: source.regions.membershipHash,
            politicalHash: source.political.sourceHash,
            settlementHash: source.settlements.settlementHash,
            urbanHash: source.urban.sourceHash,
            siteRegistryHash: source.sites.registryHash,
            naturalRegistryHash: source.natural?.registryHash || null,
            infrastructureTopologyHash: source.infrastructure.topologyHash,
            infrastructureRevision: Number(source.infrastructure.revision) || 0,
            elevationStatus: String(source.geography.elevationStatus) },
        world: { width: Number(source.world.width), height: Number(source.world.height),
            radius: Number(source.world.radius), totalCellCount: Number(source.world.cellCount) },
        cells, settlements, districts, sites, segments, identities,
        diagnostics: { projectedCellCount: cells.length,
            projectedSettlementCount: settlements.length,
            projectedDistrictCount: districts.length,
            projectedSiteCount: sites.length,
            projectedSegmentCount: segments.length,
            identityCount: Object.keys(identities).length }
    };
    payload.staticHash = story3DProjectionHash({ source: payload.source,
        scope: payload.scope, cells, settlements, districts, sites, segments });
    const frozen = story3DProjectionFreeze(payload);
    STORY_3D_PROJECTION_STATIC_CACHE = { sourceKey, snapshot: frozen };
    return frozen;
}

function story3DProjectionDynamicSnapshot(staticSnapshot, options) {
    const scope = staticSnapshot.scope;
    const world = storyHexWorldEnsure();
    const transport = typeof storyTransportRenderSnapshot === 'function'
        ? storyTransportRenderSnapshot({ world, zoomRatio: 99,
            materializeZoomRatio: 1.35 }) : { agents: [], shipmentCount: 0, cargoQuantity: 0 };
    const identities = {};
    const agents = [];
    for (const agent of transport.agents || []) {
        if (!story3DProjectionScopeIncludes(scope, agent.x, agent.y)) continue;
        const renderId = `agent:${agent.agentId}`;
        const mapEntity = story3DProjectionMapEntity('TRANSPORT_AGENT', {
            agentId: String(agent.agentId), shipmentId: String(agent.shipmentId)
        });
        identities[renderId] = mapEntity;
        agents.push({ renderId, agentId: String(agent.agentId),
            shipmentId: String(agent.shipmentId), vehicleClass: String(agent.vehicleClass),
            mode: String(agent.mode), state: String(agent.state), status: String(agent.status),
            cargoQuantity: Number(agent.cargoQuantity) || 0,
            resourceId: String(agent.resourceId || ''),
            currentCellIndex: Number(agent.currentCellIndex),
            nextCellIndex: Number(agent.nextCellIndex),
            progressBps: Number(agent.progressBps) || 0,
            x: Number(agent.x), y: Number(agent.y), angle: Number(agent.angle) || 0,
            mapEntity });
    }
    const payload = { clock: Number(STORY.clock) || 0, year: Number(STORY.year) || 0,
        agents, identities,
        diagnostics: { projectedAgentCount: agents.length,
            worldShipmentCount: Number(transport.shipmentCount) || 0,
            worldCargoQuantity: Number(transport.cargoQuantity) || 0 } };
    payload.dynamicHash = story3DProjectionHash({ clock: payload.clock,
        year: payload.year, agents });
    return story3DProjectionFreeze(payload);
}

function story3DProjectionSnapshot(options) {
    const staticSnapshot = story3DProjectionStaticSnapshot(options || {});
    const dynamicSnapshot = story3DProjectionDynamicSnapshot(staticSnapshot, options || {});
    const snapshot = {
        schemaVersion: STORY_3D_PROJECTION_SCHEMA_VERSION,
        adapterVersion: STORY_3D_PROJECTION_ADAPTER_VERSION,
        rendererAuthority: 'READ_ONLY',
        static: staticSnapshot,
        dynamic: dynamicSnapshot,
        projectionHash: story3DProjectionHash(
            `${staticSnapshot.staticHash}|${dynamicSnapshot.dynamicHash}`)
    };
    return story3DProjectionFreeze(snapshot);
}

function story3DProjectionResolveIdentity(snapshot, renderId) {
    if (!snapshot || !renderId) return null;
    return snapshot.dynamic && snapshot.dynamic.identities[renderId]
        || snapshot.static && snapshot.static.identities[renderId] || null;
}

function story3DProjectionValidate(snapshot) {
    const issues = [];
    const add = (code, path) => issues.push({ code, path });
    if (!snapshot || snapshot.schemaVersion !== STORY_3D_PROJECTION_SCHEMA_VERSION) {
        return { ok: false, issues: [{ code: 'SCHEMA_VERSION', path: '$' }] };
    }
    if (snapshot.adapterVersion !== STORY_3D_PROJECTION_ADAPTER_VERSION) add('ADAPTER_VERSION', '$.adapterVersion');
    if (snapshot.rendererAuthority !== 'READ_ONLY') add('RENDERER_AUTHORITY', '$.rendererAuthority');
    if (!Object.isFrozen(snapshot) || !Object.isFrozen(snapshot.static)
        || !Object.isFrozen(snapshot.dynamic)) add('NOT_IMMUTABLE', '$');
    const renderIds = [];
    for (const group of ['cells', 'settlements', 'districts', 'sites', 'segments']) {
        if (!Array.isArray(snapshot.static[group])) add('STATIC_GROUP', `$.static.${group}`);
        else renderIds.push(...snapshot.static[group].map(row => row.renderId));
    }
    if (!Array.isArray(snapshot.dynamic.agents)) add('DYNAMIC_AGENTS', '$.dynamic.agents');
    else renderIds.push(...snapshot.dynamic.agents.map(row => row.renderId));
    if (renderIds.some(id => !id)) add('RENDER_ID_REQUIRED', '$.identities');
    if (new Set(renderIds).size !== renderIds.length) add('RENDER_ID_DUPLICATE', '$.identities');
    for (const id of renderIds) {
        if (!story3DProjectionResolveIdentity(snapshot, id)) add('IDENTITY_MISSING', `$.identities.${id}`);
    }
    return { ok: issues.length === 0, issues,
        counts: { renderIds: renderIds.length,
            cells: snapshot.static.cells.length,
            agents: snapshot.dynamic.agents.length } };
}

function story3DProjectionAuthorityDigest() {
    const world = storyHexWorldEnsure();
    const geography = storyHexGeographyEnsure();
    const regions = storyHexRegionsEnsure();
    const settlements = storyHexSettlementsEnsure();
    const sites = storyHexSitesEnsure();
    const infrastructure = storyHexInfrastructureSegmentsEnsure();
    const trade = typeof storyTradeEnsure === 'function' ? storyTradeEnsure() : null;
    return story3DProjectionHash({
        world: world.layoutHash, geography: geography.geographyHash,
        regions: regions.membershipHash, settlements: settlements.settlementHash,
        sites: sites.registryHash,
        infrastructure: [infrastructure.topologyHash, infrastructure.revision,
            infrastructure.segments.map(row => [row.id, row.enabled, row.damageBps,
                row.maintenanceBps, row.lifecycleState])],
        nodes: (STORY.nodes || []).map(node => [node.id, node.owner, node.level]),
        trade: trade ? (trade.shipments || []).map(row => [row.id, row.status,
            row.quantity, row.transportAgent && row.transportAgent.stepIndex,
            row.transportAgent && row.transportAgent.stepProgressBps]) : []
    });
}

function story3DProjectionResetCache() {
    STORY_3D_PROJECTION_STATIC_CACHE = null;
}
