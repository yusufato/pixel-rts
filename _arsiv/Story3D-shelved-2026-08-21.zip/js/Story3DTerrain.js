'use strict';

// HXD-9C.2 — immutable projection -> renderer-owned terrain instance plan.
// No THREE dependency belongs here: the compiler is deterministic, headless-testable
// and cannot mutate simulation authority.
const STORY_3D_TERRAIN_SCHEMA_VERSION = 2;
const STORY_3D_TERRAIN_ADAPTER_VERSION = 'story-3d-terrain-1';
const STORY_3D_TERRAIN_HEIGHT_MODE = 'SMOOTH_CANONICAL_INTENSITY';
const STORY_3D_TERRAIN_TYPES = Object.freeze(['WATER', 'LAND', 'COAST', 'MOUNTAIN']);
const STORY_3D_TERRAIN_LODS = Object.freeze([
    Object.freeze({ id: 'NEAR', maxViewHeight: 28, radialSegments: 6, detail: 'VOLUME' }),
    Object.freeze({ id: 'MID', maxViewHeight: 70, radialSegments: 6, detail: 'REDUCED' }),
    Object.freeze({ id: 'FAR', maxViewHeight: Infinity, radialSegments: 6, detail: 'SURFACE' }),
]);

function story3DTerrainProtectedLandCells(snapshot) {
    const protectedCells = new Set();
    for (const row of snapshot?.static?.settlements || []) {
        protectedCells.add(Number(row.coreCellIndex));
        if (Number.isFinite(Number(row.portLandCellIndex))) protectedCells.add(Number(row.portLandCellIndex));
    }
    for (const row of snapshot?.static?.districts || []) protectedCells.add(Number(row.cellIndex));
    for (const row of snapshot?.static?.sites || []) protectedCells.add(Number(row.cellIndex));
    return protectedCells;
}

function story3DTerrainType(cell, protectedLandCells) {
    const terrainClass = Number(cell.terrainClass);
    if (terrainClass === 0) return 'WATER';
    // The canonical coast raster stores mixed land/water coverage. Rendering
    // every mixed cell as solid land filled narrow seas (notably the
    // Bosphorus) with sand. At hex resolution, water-majority coast cells are
    // water unless a canonical settlement/site explicitly occupies the land.
    if (terrainClass === 2) {
        const landCoverageBps = Math.max(0, Math.min(10000, Number(cell.landCoverageBps) || 0));
        if (landCoverageBps < 4500 && !protectedLandCells?.has(Number(cell.cellIndex))) return 'WATER';
        return 'COAST';
    }
    if (terrainClass === 3) return 'MOUNTAIN';
    return 'LAND';
}

function story3DTerrainHeight(cell, type) {
    if (type === 'WATER') return 0.18;
    if (type === 'COAST') return 0.48;
    if (type === 'MOUNTAIN') {
        const intensity = Math.max(0, Math.min(10000, Number(cell.mountainIntensityBps) || 0));
        return 2.4 + intensity / 10000 * 2.8;
    }
    return 0.72;
}

function story3DTerrainCompile(snapshot, options) {
    if (!snapshot || snapshot.rendererAuthority !== 'READ_ONLY' || !snapshot.static) {
        throw new Error('STORY_3D_TERRAIN_PROJECTION_REQUIRED');
    }
    const cells = snapshot.static.cells || [];
    if (!cells.length) throw new Error('STORY_3D_TERRAIN_CELLS_REQUIRED');
    const radius = Math.max(1e-6, Number(snapshot.static.world.radius) || 1);
    const chunkSize = Math.max(4, Math.floor(Number(options && options.chunkSize) || 16));
    const scope = snapshot.static.scope;
    const originX = (Number(scope.minX) + Number(scope.maxX)) / 2;
    const originY = (Number(scope.minY) + Number(scope.maxY)) / 2;
    const groups = Object.fromEntries(STORY_3D_TERRAIN_TYPES.map(type => [type, []]));
    const chunks = Object.create(null);
    const identities = Object.create(null);
    const protectedLandCells = story3DTerrainProtectedLandCells(snapshot);
    let waterMajorityCoastCount = 0;
    let minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity, maxHeight = 0;

    for (const cell of cells) {
        const type = story3DTerrainType(cell, protectedLandCells);
        if (type === 'WATER' && Number(cell.terrainClass) === 2) waterMajorityCoastCount++;
        const height = story3DTerrainHeight(cell, type);
        const x = (Number(cell.x) - originX) / radius;
        const z = (Number(cell.y) - originY) / radius;
        const chunkId = `${Math.floor(Number(cell.q) / chunkSize)}:${Math.floor(Number(cell.r) / chunkSize)}`;
        const instance = Object.freeze({
            renderId: String(cell.renderId), cellId: String(cell.cellId),
            cellIndex: Number(cell.cellIndex), q: Number(cell.q), r: Number(cell.r),
            x, z, height, type, chunkId,
            ownerId: Number(cell.ownerId), landCoverageBps: Number(cell.landCoverageBps),
            mountainIntensityBps: Number(cell.mountainIntensityBps),
            riverPresence: Number(cell.riverPresence) || 0,
            coastEdgeMask: Number(cell.coastEdgeMask) || 0,
            naturalCoverCode: Number(cell.naturalCoverCode),
            naturalCover: String(cell.naturalCover || 'UNKNOWN'),
            resourceCode: Number(cell.resourceCode) || 0,
            arableSuitabilityBps: Number(cell.arableSuitabilityBps) || 0,
            forestrySuitabilityBps: Number(cell.forestrySuitabilityBps) || 0,
        });
        groups[type].push(instance);
        if (!chunks[chunkId]) chunks[chunkId] = [];
        chunks[chunkId].push(instance.renderId);
        identities[instance.renderId] = cell.mapEntity;
        minX = Math.min(minX, x - 1); maxX = Math.max(maxX, x + 1);
        minZ = Math.min(minZ, z - 1); maxZ = Math.max(maxZ, z + 1);
        maxHeight = Math.max(maxHeight, height);
    }

    for (const type of STORY_3D_TERRAIN_TYPES) Object.freeze(groups[type]);
    for (const id of Object.keys(chunks)) Object.freeze(chunks[id]);
    const plan = {
        schemaVersion: STORY_3D_TERRAIN_SCHEMA_VERSION,
        adapterVersion: STORY_3D_TERRAIN_ADAPTER_VERSION,
        sourceStaticHash: snapshot.static.staticHash,
        rendererAuthority: 'READ_ONLY',
        heightMode: STORY_3D_TERRAIN_HEIGHT_MODE,
        unitScale: radius,
        hexRadius: 1,
        origin: Object.freeze({ x: originX, y: originY }),
        bounds: Object.freeze({ minX, maxX, minZ, maxZ, maxHeight,
            width: maxX - minX, depth: maxZ - minZ }),
        lods: STORY_3D_TERRAIN_LODS,
        groups: Object.freeze(groups), chunks: Object.freeze(chunks),
        identities: Object.freeze(identities),
        diagnostics: Object.freeze({ cellCount: cells.length,
            instanceCount: STORY_3D_TERRAIN_TYPES.reduce((sum, type) => sum + groups[type].length, 0),
            chunkCount: Object.keys(chunks).length,
            drawGroupCount: STORY_3D_TERRAIN_TYPES.filter(type => groups[type].length).length,
            waterCount: groups.WATER.length, landCount: groups.LAND.length,
            coastCount: groups.COAST.length, mountainCount: groups.MOUNTAIN.length,
            waterMajorityCoastCount, protectedLandCellCount: protectedLandCells.size })
    };
    return Object.freeze(plan);
}

function story3DTerrainValidate(plan, snapshot) {
    const issues = [];
    const add = (code, detail) => issues.push({ code, detail });
    if (!plan || plan.schemaVersion !== STORY_3D_TERRAIN_SCHEMA_VERSION) add('SCHEMA', 'terrain');
    if (plan && plan.rendererAuthority !== 'READ_ONLY') add('AUTHORITY', plan.rendererAuthority);
    if (plan && plan.heightMode !== STORY_3D_TERRAIN_HEIGHT_MODE) add('HEIGHT_MODE', plan.heightMode);
    if (plan && !Object.isFrozen(plan)) add('IMMUTABLE', 'plan');
    if (plan && snapshot && plan.sourceStaticHash !== snapshot.static.staticHash) add('SOURCE_HASH', plan.sourceStaticHash);
    if (plan && snapshot && plan.diagnostics.instanceCount !== snapshot.static.cells.length) add('CELL_PARITY', plan.diagnostics.instanceCount);
    const ids = plan ? STORY_3D_TERRAIN_TYPES.flatMap(type => plan.groups[type].map(row => row.renderId)) : [];
    if (new Set(ids).size !== ids.length) add('DUPLICATE_ID', ids.length);
    if (plan && ids.some(id => !plan.identities[id])) add('IDENTITY', 'missing');
    return Object.freeze({ ok: issues.length === 0, issues: Object.freeze(issues),
        counts: Object.freeze({ instances: ids.length, chunks: plan ? plan.diagnostics.chunkCount : 0 }) });
}
