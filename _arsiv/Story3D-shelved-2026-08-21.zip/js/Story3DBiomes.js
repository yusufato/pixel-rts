'use strict';

// HXD-9C.2c — deterministic decorative biome placement.
// Placements are renderer detail only: they cannot create resources, movement
// costs or simulation truth. Occupied settlement/site and transport corridor
// cells stay clear so vegetation cannot grow through roads and rails.
const STORY_3D_BIOME_SCHEMA_VERSION = 3;
const STORY_3D_BIOME_ASSETS = Object.freeze({
    TREE_OAK: 'assets/vendor/kenney-nature-kit/glb/tree_oak.glb',
    TREE_DEFAULT: 'assets/vendor/kenney-nature-kit/glb/tree_default.glb',
    TREE_PINE_TALL: 'assets/vendor/kenney-nature-kit/glb/tree_pineTallA.glb',
    TREE_PINE_ROUND: 'assets/vendor/kenney-nature-kit/glb/tree_pineRoundB.glb',
    BUSH: 'assets/vendor/kenney-nature-kit/glb/plant_bush.glb',
    ROCK_LARGE_A: 'assets/vendor/kenney-nature-kit/glb/rock_largeA.glb',
    ROCK_LARGE_B: 'assets/vendor/kenney-nature-kit/glb/rock_largeB.glb',
    ROCK_TALL_A: 'assets/vendor/kenney-nature-kit/glb/rock_tallA.glb',
    ROCK_TALL_B: 'assets/vendor/kenney-nature-kit/glb/rock_tallB.glb',
    CLIFF_LARGE: 'assets/vendor/kenney-nature-kit/glb/cliff_large_rock.glb'
});

function story3DBiomeHash(q, r, salt) {
    let value = Math.imul((q | 0) ^ 0x9e3779b9, 0x85ebca6b)
        ^ Math.imul((r | 0) ^ (salt | 0), 0xc2b2ae35);
    value ^= value >>> 16; value = Math.imul(value, 0x7feb352d);
    value ^= value >>> 15; value = Math.imul(value, 0x846ca68b);
    return (value ^ (value >>> 16)) >>> 0;
}
function story3DBiomeUnit(q, r, salt) { return story3DBiomeHash(q, r, salt) / 0xffffffff; }
function story3DBiomeOccupied(snapshot) {
    const occupied = new Set();
    for (const row of snapshot?.static?.settlements || []) occupied.add(Number(row.coreCellIndex));
    for (const row of snapshot?.static?.districts || []) occupied.add(Number(row.cellIndex));
    for (const row of snapshot?.static?.sites || []) occupied.add(Number(row.cellIndex));
    for (const row of snapshot?.static?.segments || []) {
        if (!row.enabled || (row.mode !== 'LAND' && row.mode !== 'RAIL')) continue;
        for (const cellIndex of row.endpointCellIndices || []) occupied.add(Number(cellIndex));
    }
    return occupied;
}

function story3DBiomeCorridorCells(snapshot) {
    const corridorCells = new Set();
    for (const row of snapshot?.static?.segments || []) {
        if (!row.enabled || (row.mode !== 'LAND' && row.mode !== 'RAIL')) continue;
        for (const cellIndex of row.endpointCellIndices || []) corridorCells.add(Number(cellIndex));
    }
    return corridorCells;
}

function story3DBiomesCompile(plan, snapshot, surface) {
    if (!plan || plan.rendererAuthority !== 'READ_ONLY') throw new Error('STORY_3D_BIOME_TERRAIN_PLAN_REQUIRED');
    const occupied = story3DBiomeOccupied(snapshot);
    const corridorCells = story3DBiomeCorridorCells(snapshot);
    const placements = [];
    const rows = ['LAND', 'COAST', 'MOUNTAIN'].flatMap(type => plan.groups[type] || []);
    for (const row of rows) {
        if (occupied.has(row.cellIndex) || row.type === 'COAST') continue;
        const surfaceY = Number(surface?.cellHeights?.[row.renderId]);
        const placementY = Number.isFinite(surfaceY) ? surfaceY : 0.72;
        const mountainStrength = Math.max(0, Number(row.mountainIntensityBps) || 0);
        if (row.naturalCover === 'MOUNTAIN' || row.type === 'MOUNTAIN' || mountainStrength >= 2200) {
            const count = 2 + story3DBiomeHash(row.q, row.r, 90) % 2;
            for (let slot = 0; slot < count; slot++) {
                const angle = story3DBiomeUnit(row.q, row.r, 100 + slot) * Math.PI * 2;
                const distance = 0.08 + story3DBiomeUnit(row.q, row.r, 110 + slot) * 0.38;
                placements.push(Object.freeze({ kind: 'MOUNTAIN',
                    assetId: ['ROCK_TALL_A', 'ROCK_TALL_B', 'ROCK_LARGE_A'][slot % 3],
                    renderId: `biome:mountain:${row.cellId}:${slot}`, cellIndex: row.cellIndex, cellRenderId: row.renderId,
                    x: row.x + Math.cos(angle) * distance, y: placementY, z: row.z + Math.sin(angle) * distance,
                    rotationY: angle, desiredHeight: 0.72 + story3DBiomeUnit(row.q, row.r, 120 + slot) * 0.28 }));
            }
            continue;
        }
        // Forest cover now comes from the canonical natural-cover ledger.
        // Placement inside that cell is renderer-only decoration; the ledger
        // remains the sole authority for whether the cell is forest.
        if (row.naturalCover !== 'FOREST') continue;
        const densityRoll = story3DBiomeUnit(row.q, row.r, 10);
        if (densityRoll > 0.88) continue;
        const count = 3 + story3DBiomeHash(row.q, row.r, 11) % 3;
        const conifer = story3DBiomeUnit(row.q, row.r, 12) > 0.58;
        for (let slot = 0; slot < count; slot++) {
            const angle = story3DBiomeUnit(row.q, row.r, 20 + slot) * Math.PI * 2;
            const distance = 0.12 + story3DBiomeUnit(row.q, row.r, 30 + slot) * 0.48;
            const assetId = conifer
                ? (slot % 2 ? 'TREE_PINE_ROUND' : 'TREE_PINE_TALL')
                : (slot % 2 ? 'TREE_DEFAULT' : 'TREE_OAK');
            placements.push(Object.freeze({ kind: 'FOREST', assetId,
                renderId: `biome:forest:${row.cellId}:${slot}`, cellIndex: row.cellIndex, cellRenderId: row.renderId,
                x: row.x + Math.cos(angle) * distance, y: placementY, z: row.z + Math.sin(angle) * distance,
                rotationY: angle, desiredHeight: 0.85 + story3DBiomeUnit(row.q, row.r, 40 + slot) * 0.42 }));
        }
        if (count >= 4) placements.push(Object.freeze({ kind: 'BUSH', assetId: 'BUSH',
            renderId: `biome:bush:${row.cellId}`, cellIndex: row.cellIndex, cellRenderId: row.renderId,
            x: row.x, y: placementY, z: row.z, rotationY: 0,
            desiredHeight: 0.28 + story3DBiomeUnit(row.q, row.r, 51) * 0.14 }));
    }
    const byAsset = {};
    for (const placement of placements) {
        if (!byAsset[placement.assetId]) byAsset[placement.assetId] = [];
        byAsset[placement.assetId].push(placement);
    }
    for (const id of Object.keys(byAsset)) Object.freeze(byAsset[id]);
    return Object.freeze({ schemaVersion: STORY_3D_BIOME_SCHEMA_VERSION,
        sourceStaticHash: plan.sourceStaticHash, sourceSurfaceHash: surface?.sourceStaticHash || null,
        rendererAuthority: 'READ_ONLY_DECORATION',
        assets: STORY_3D_BIOME_ASSETS, placements: Object.freeze(placements),
        byAsset: Object.freeze(byAsset), diagnostics: Object.freeze({
            placementCount: placements.length,
            forestCount: placements.filter(row => row.kind === 'FOREST').length,
            mountainCount: placements.filter(row => row.kind === 'MOUNTAIN').length,
            assetCount: Object.keys(byAsset).length, occupiedCellCount: occupied.size,
            corridorCellCount: corridorCells.size
        }) });
}

function story3DBiomesValidate(result, plan, snapshot, surface) {
    const issues = [];
    if (!result || result.schemaVersion !== STORY_3D_BIOME_SCHEMA_VERSION) issues.push('SCHEMA');
    if (result && plan && result.sourceStaticHash !== plan.sourceStaticHash) issues.push('SOURCE_HASH');
    if (result && surface && result.sourceSurfaceHash !== surface.sourceStaticHash) issues.push('SURFACE_HASH');
    const occupied = story3DBiomeOccupied(snapshot);
    if (result && result.placements.some(row => occupied.has(row.cellIndex))) issues.push('OCCUPIED_CELL');
    if (result && new Set(result.placements.map(row => row.renderId)).size !== result.placements.length) issues.push('DUPLICATE_ID');
    if (result && result.placements.some(row => !result.assets[row.assetId])) issues.push('UNKNOWN_ASSET');
    if (result && surface && result.placements.some(row => Math.abs(row.y - surface.cellHeights[row.cellRenderId]) > 1e-9)) issues.push('SURFACE_HEIGHT');
    return Object.freeze({ ok: issues.length === 0, issues: Object.freeze(issues) });
}

if (typeof window !== 'undefined') {
    window.story3DBiomesCompile = story3DBiomesCompile;
    window.story3DBiomesValidate = story3DBiomesValidate;
}
if (typeof module !== 'undefined' && module.exports) module.exports = {
    STORY_3D_BIOME_SCHEMA_VERSION, STORY_3D_BIOME_ASSETS,
    story3DBiomeHash, story3DBiomesCompile, story3DBiomesValidate
};
