'use strict';

// HXD-9C.2e — canonical infrastructure segments -> deterministic 3D road deck.
// Visual damage may be represented later, but this adapter cannot repair,
// enable, disable or otherwise mutate a simulation segment.
const STORY_3D_INFRA_SCHEMA_VERSION = 3;
const STORY_3D_INFRA_ASSETS = Object.freeze({
    ROAD_STRAIGHT: 'assets/vendor/kenney-city-roads/glb/road-straight.glb',
    ROAD_BRIDGE: 'assets/vendor/kenney-city-roads/glb/road-bridge.glb',
    ROAD_INTERSECTION: 'assets/vendor/kenney-city-roads/glb/road-intersection.glb',
    ROAD_CROSSROAD: 'assets/vendor/kenney-city-roads/glb/road-crossroad.glb'
});

function story3DInfrastructureCompile(plan, snapshot, surface) {
    if (!plan || plan.rendererAuthority !== 'READ_ONLY') throw new Error('STORY_3D_INFRA_TERRAIN_PLAN_REQUIRED');
    if (!snapshot?.static) throw new Error('STORY_3D_INFRA_PROJECTION_REQUIRED');
    const cells = new Map();
    for (const row of ['WATER', 'LAND', 'COAST', 'MOUNTAIN'].flatMap(type => plan.groups[type] || [])) {
        cells.set(row.cellIndex, row);
    }
    const placements = [];
    const occupiedCells = new Set();
    for (const row of snapshot.static.settlements || []) occupiedCells.add(Number(row.coreCellIndex));
    for (const row of snapshot.static.districts || []) occupiedCells.add(Number(row.cellIndex));
    for (const row of snapshot.static.sites || []) occupiedCells.add(Number(row.cellIndex));
    let trimmedEndCount = 0;
    const junctionLinks = new Map();
    for (const segment of snapshot.static.segments || []) {
        if (!segment.enabled || segment.mode !== 'LAND') continue;
        const a = cells.get(Number(segment.endpointCellIndices?.[0]));
        const b = cells.get(Number(segment.endpointCellIndices?.[1]));
        if (!a || !b) continue;
        for (const [cell, other] of [[a, b], [b, a]]) {
            if (!junctionLinks.has(cell.cellIndex)) junctionLinks.set(cell.cellIndex, []);
            junctionLinks.get(cell.cellIndex).push({ segment, cell, other });
        }
        const dx = b.x - a.x, dz = b.z - a.z;
        const horizontalLength = Math.hypot(dx, dz);
        if (horizontalLength < 0.001) continue;
        const ay = Number(surface?.cellHeights?.[a.renderId]) || 0.72;
        const by = Number(surface?.cellHeights?.[b.renderId]) || 0.72;
        const trimA = occupiedCells.has(a.cellIndex) ? Math.min(0.46, horizontalLength * 0.28) : 0;
        const trimB = occupiedCells.has(b.cellIndex) ? Math.min(0.46, horizontalLength * 0.28) : 0;
        const ux = dx / horizontalLength, uz = dz / horizontalLength;
        const startT = trimA / horizontalLength;
        const endT = trimB / horizontalLength;
        const startX = a.x + ux * trimA, startZ = a.z + uz * trimA;
        const endX = b.x - ux * trimB, endZ = b.z - uz * trimB;
        const startY = ay + (by - ay) * startT;
        const endY = by - (by - ay) * endT;
        const visibleHorizontalLength = Math.hypot(endX - startX, endZ - startZ);
        if (visibleHorizontalLength < 0.08) continue;
        const trimmedEnds = Number(trimA > 0) + Number(trimB > 0);
        trimmedEndCount += trimmedEnds;
        placements.push(Object.freeze({
            renderId: `infra3d:${segment.segmentId}`,
            sourceRenderId: segment.renderId,
            segmentId: segment.segmentId,
            segmentKind: segment.segmentKind,
            assetId: segment.segmentKind === 'BRIDGE' ? 'ROAD_BRIDGE' : 'ROAD_STRAIGHT',
            x: (startX + endX) / 2,
            y: (startY + endY) / 2 + 0.018,
            z: (startZ + endZ) / 2,
            rotationY: Math.atan2(dx, dz),
            pitch: Math.atan2(endY - startY, visibleHorizontalLength),
            desiredLength: Math.hypot(visibleHorizontalLength, endY - startY),
            rawLength: Math.hypot(horizontalLength, by - ay),
            trimmedEnds,
            desiredWidth: segment.segmentKind === 'BRIDGE' ? 0.29 : 0.24,
            damageBps: Math.max(0, Number(segment.damageBps) || 0),
            maintenanceBps: Math.max(0, Number(segment.maintenanceBps) || 0),
            endpointCellIndices: Object.freeze([a.cellIndex, b.cellIndex])
        }));
    }
    // Straight segment meshes alone overlap awkwardly at three/four-way
    // nodes. Place one real road-junction asset over canonical graph nodes;
    // this remains a visualization of existing links, never new topology.
    for (const links of junctionLinks.values()) {
        if (links.length < 3) continue;
        const anchor = links[0].cell;
        if (occupiedCells.has(anchor.cellIndex)) continue;
        const degree = Math.min(4, links.length);
        const first = links[0].other;
        const rotationY = Math.atan2(first.x - anchor.x, first.z - anchor.z);
        const y = (Number(surface?.cellHeights?.[anchor.renderId]) || 0.72) + 0.022;
        placements.push(Object.freeze({
            renderId: `infra3d:junction:${anchor.cellIndex}`,
            sourceRenderId: links[0].segment.renderId,
            segmentId: `junction:${anchor.cellIndex}`,
            segmentKind: 'JUNCTION',
            assetId: degree >= 4 ? 'ROAD_CROSSROAD' : 'ROAD_INTERSECTION',
            x: anchor.x, y, z: anchor.z, rotationY, pitch: 0,
            desiredLength: 0.48, rawLength: 0.48, desiredWidth: 0.48,
            trimmedEnds: 0, damageBps: 0, maintenanceBps: 10000,
            endpointCellIndices: Object.freeze([anchor.cellIndex, anchor.cellIndex])
        }));
    }
    const byAsset = {};
    for (const placement of placements) {
        if (!byAsset[placement.assetId]) byAsset[placement.assetId] = [];
        byAsset[placement.assetId].push(placement);
    }
    for (const rows of Object.values(byAsset)) Object.freeze(rows);
    return Object.freeze({
        schemaVersion: STORY_3D_INFRA_SCHEMA_VERSION,
        sourceStaticHash: plan.sourceStaticHash,
        sourceSurfaceHash: surface?.sourceStaticHash || null,
        rendererAuthority: 'READ_ONLY_VISUALIZATION',
        assets: STORY_3D_INFRA_ASSETS,
        placements: Object.freeze(placements),
        byAsset: Object.freeze(byAsset),
        diagnostics: Object.freeze({
            placementCount: placements.length,
            roadCount: placements.filter(row => row.segmentKind === 'ROAD').length,
            bridgeCount: placements.filter(row => row.segmentKind === 'BRIDGE').length,
            junctionCount: placements.filter(row => row.segmentKind === 'JUNCTION').length,
            damagedCount: placements.filter(row => row.damageBps > 0).length,
            assetCount: Object.keys(byAsset).length,
            trimmedEndCount, occupiedCellCount: occupiedCells.size
        })
    });
}

function story3DInfrastructureValidate(result, plan, snapshot, surface) {
    const issues = [];
    if (!result || result.schemaVersion !== STORY_3D_INFRA_SCHEMA_VERSION) issues.push('SCHEMA');
    if (result && plan && result.sourceStaticHash !== plan.sourceStaticHash) issues.push('SOURCE_HASH');
    if (result && surface && result.sourceSurfaceHash !== surface.sourceStaticHash) issues.push('SURFACE_HASH');
    if (result && new Set(result.placements.map(row => row.renderId)).size !== result.placements.length) issues.push('DUPLICATE_ID');
    if (result && result.placements.some(row => !result.assets[row.assetId])) issues.push('UNKNOWN_ASSET');
    const sourceIds = new Set((snapshot?.static?.segments || []).map(row => row.renderId));
    if (result && result.placements.some(row => !sourceIds.has(row.sourceRenderId))) issues.push('SOURCE_ID');
    if (result && result.placements.some(row => row.desiredLength <= 0 || row.desiredWidth <= 0)) issues.push('DIMENSION');
    return Object.freeze({ ok: issues.length === 0, issues: Object.freeze(issues) });
}

if (typeof window !== 'undefined') {
    window.story3DInfrastructureCompile = story3DInfrastructureCompile;
    window.story3DInfrastructureValidate = story3DInfrastructureValidate;
}
if (typeof module !== 'undefined' && module.exports) module.exports = {
    STORY_3D_INFRA_SCHEMA_VERSION, STORY_3D_INFRA_ASSETS,
    story3DInfrastructureCompile, story3DInfrastructureValidate
};
