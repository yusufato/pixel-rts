// HXD-9C.1 — Three.js/WebGL2 yaşam döngüsü kabuğu.
// Bu modül simülasyona yazamaz. İlk aşamada yalnız açık --story-renderer=3d
// isteğinde boş bir 3D sahne kurar; içerik HXD-9C.2'de projection snapshot'tan gelir.
const THREE_MODULE_PATH = '../node_modules/three/build/three.module.js';
let THREE = null;
let GLTFLoaderClass = null;

const STATUS = Object.freeze({
    DISABLED_2D: 'DISABLED_2D',
    BOOTING: 'BOOTING',
    READY_SHELL: 'READY_SHELL',
    READY_WORLD: 'READY_WORLD',
    FALLBACK_2D: 'FALLBACK_2D',
    CONTEXT_LOST: 'CONTEXT_LOST',
    DISPOSED: 'DISPOSED',
});

const state = {
    requested: window.PIXEL?.rendering?.requestedStoryRenderer === '3d' ? '3d' : '2d',
    active: '2d',
    status: STATUS.DISABLED_2D,
    reason: null,
    renderer: null,
    scene: null,
    camera: null,
    canvas: null,
    resizeObserver: null,
    screenObserver: null,
    frameHandle: 0,
    frameCount: 0,
    terrainRoot: null,
    terrainPlan: null,
    terrainStaticHash: null,
    viewHeight: 100,
    fitViewHeight: 100,
    currentLod: 'FAR',
    cameraTarget: null,
    inputAbort: null,
    politicalOverlay: null,
    // HXD-9C.2 kabulünde arazi önce kendi başına okunur olmalı. Politik katman
    // P ile açılır; kompozit doğrulanmadan yüzeyi varsayılan olarak örtemez.
    politicalEnabled: false,
    detailLayers: null,
    surfacePlan: null,
    biomePlan: null,
    biomeLayer: null,
    settlementPlan: null,
    settlementLayer: null,
    infrastructurePlan: null,
    infrastructureLayer: null,
    terrainTextures: null,
    labelLayer: null,
    cityLabels: [],
    assetStatus: 'IDLE',
    assetError: null,
    diagnosticsElement: null,
};

function publicSnapshot() {
    const info = state.renderer?.info;
    return Object.freeze({
        requested: state.requested,
        active: state.active,
        status: state.status,
        reason: state.reason,
        threeRevision: THREE?.REVISION || null,
        // Renderer yalnız yukarıda açıkça alınan `webgl2` context ile kurulabilir.
        webgl2: Boolean(state.renderer),
        frameCount: state.frameCount,
        renderCalls: info?.render?.calls || 0,
        triangles: info?.render?.triangles || 0,
        terrainInstances: state.terrainPlan?.diagnostics?.instanceCount || 0,
        terrainDrawGroups: state.terrainPlan?.diagnostics?.drawGroupCount || 0,
        terrainChunks: state.terrainPlan?.diagnostics?.chunkCount || 0,
        heightMode: state.terrainPlan?.heightMode || null,
        lod: state.currentLod,
        politicalOverlay: state.politicalOverlay?.visible === true,
        coastDetail: state.detailLayers?.coast?.visible === true,
        coastNearDetail: state.detailLayers?.coastNear?.visible === true,
        biomeInstances: state.biomePlan?.diagnostics?.placementCount || 0,
        biomeAssets: state.biomePlan?.diagnostics?.assetCount || 0,
        settlementInstances: state.settlementPlan?.diagnostics?.placementCount || 0,
        settlementAssets: state.settlementPlan?.diagnostics?.assetCount || 0,
        settlementEra: state.settlementPlan?.visualEra || null,
        infrastructureInstances: state.infrastructurePlan?.diagnostics?.placementCount || 0,
        infrastructureAssets: state.infrastructurePlan?.diagnostics?.assetCount || 0,
        cityLabels: state.cityLabels.length,
        assetStatus: state.assetStatus,
        assetError: state.assetError,
    });
}

function updateLod() {
    const lod = state.terrainPlan?.lods?.find(row => state.viewHeight <= row.maxViewHeight);
    state.currentLod = lod?.id || 'FAR';
    if (state.detailLayers) {
        state.detailLayers.coast.visible = state.currentLod !== 'FAR';
        state.detailLayers.coastNear.visible = state.currentLod === 'NEAR';
    }
    if (state.politicalOverlay) state.politicalOverlay.visible = state.politicalEnabled;
    if (state.biomeLayer) state.biomeLayer.visible = state.currentLod !== 'FAR';
    if (state.settlementLayer) state.settlementLayer.visible = state.currentLod !== 'FAR';
    if (state.infrastructureLayer) state.infrastructureLayer.visible = state.currentLod !== 'FAR';
}

function ownerColor(ownerId) {
    const color = new THREE.Color();
    color.setHSL((((Number(ownerId) || 0) * 0.173) % 1 + 1) % 1, 0.68, 0.53, THREE.SRGBColorSpace);
    return color;
}

function terrainInstanceColor(type, row) {
    const base = new THREE.Color(TERRAIN_STYLE[type].color);
    const variation = ((((row.q * 73856093) ^ (row.r * 19349663)) >>> 0) % 1000) / 1000;
    const lightShift = (variation - 0.5) * (type === 'WATER' ? 0.08 : 0.12);
    base.offsetHSL((variation - 0.5) * 0.018, 0, lightShift);
    return base;
}

function show2DFallback(reason, status = STATUS.FALLBACK_2D) {
    state.active = '2d';
    state.status = status;
    state.reason = String(reason || '3D renderer kullanılamıyor');
    document.body.removeAttribute('data-story-renderer');
    if (state.canvas) state.canvas.hidden = true;
}

function resize() {
    if (!state.renderer || !state.canvas) return;
    const shell = state.canvas.parentElement;
    const width = Math.max(1, Math.floor(shell?.clientWidth || 1));
    const height = Math.max(1, Math.floor(shell?.clientHeight || 1));
    const pixelRatio = Math.min(window.devicePixelRatio || 1, 1.5);
    state.renderer.setPixelRatio(pixelRatio);
    state.renderer.setSize(width, height, false);
    const aspect = width / height;
    const viewHeight = state.viewHeight;
    state.camera.left = -viewHeight * aspect / 2;
    state.camera.right = viewHeight * aspect / 2;
    state.camera.top = viewHeight / 2;
    state.camera.bottom = -viewHeight / 2;
    state.camera.updateProjectionMatrix();
}

const TERRAIN_STYLE = Object.freeze({
    WATER: Object.freeze({ color: 0x21628c, roughness: 0.32, metalness: 0.08 }),
    LAND: Object.freeze({ color: 0x67865a, roughness: 0.92, metalness: 0.00 }),
    COAST: Object.freeze({ color: 0xb5aa72, roughness: 0.88, metalness: 0.00 }),
    MOUNTAIN: Object.freeze({ color: 0x77736b, roughness: 0.96, metalness: 0.00 }),
});

function clearTerrain() {
    if (!state.terrainRoot) return;
    state.terrainRoot.traverse(object => {
        object.geometry?.dispose?.();
        if (Array.isArray(object.material)) object.material.forEach(material => material.dispose?.());
        else object.material?.dispose?.();
    });
    state.scene?.remove(state.terrainRoot);
    state.terrainRoot = null;
    state.terrainPlan = null;
    state.terrainStaticHash = null;
    state.politicalOverlay = null;
    state.detailLayers = null;
    state.surfacePlan = null;
    state.biomePlan = null;
    state.biomeLayer = null;
    state.settlementPlan = null;
    state.settlementLayer = null;
    state.infrastructurePlan = null;
    state.infrastructureLayer = null;
    state.cityLabels = [];
    state.labelLayer?.replaceChildren();
    state.assetStatus = 'IDLE';
    state.assetError = null;
}

function makeSurfaceGeometry(positions, colors, indices) {
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    const uv = [];
    for (let index = 0; index < positions.length; index += 3) {
        uv.push(positions[index] / 7, positions[index + 2] / 7);
    }
    geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
    geometry.setIndex(indices);
    geometry.computeVertexNormals();
    geometry.computeBoundingSphere();
    return geometry;
}

function loadGLTF(url) {
    return new Promise((resolve, reject) => new GLTFLoaderClass().load(url, resolve, undefined, reject));
}

async function installBiomeLayer(plan, snapshot, terrainRoot) {
    if (typeof window.story3DBiomesCompile !== 'function') return;
    const biomePlan = window.story3DBiomesCompile(plan, snapshot, state.surfacePlan);
    const validation = window.story3DBiomesValidate?.(biomePlan, plan, snapshot, state.surfacePlan);
    if (validation && !validation.ok) throw new Error(`3D biome invalid: ${validation.issues.join(',')}`);
    state.biomePlan = biomePlan;
    if (!biomePlan.placements.length) return;
    const loaded = new Map();
    await Promise.all(Object.keys(biomePlan.byAsset).map(async assetId => {
        loaded.set(assetId, await loadGLTF(biomePlan.assets[assetId]));
    }));
    if (state.terrainRoot !== terrainRoot || state.terrainStaticHash !== plan.sourceStaticHash) return;
    const layer = new THREE.Group();
    layer.name = 'LOD:NEAR_MID:BiomeAssets';
    const placementMatrix = new THREE.Matrix4();
    const rotationMatrix = new THREE.Matrix4();
    const scaleMatrix = new THREE.Matrix4();
    const anchorMatrix = new THREE.Matrix4();
    for (const [assetId, placements] of Object.entries(biomePlan.byAsset)) {
        const gltf = loaded.get(assetId);
        gltf.scene.updateMatrixWorld(true);
        const bounds = new THREE.Box3().setFromObject(gltf.scene);
        const size = bounds.getSize(new THREE.Vector3());
        const center = bounds.getCenter(new THREE.Vector3());
        const unitHeight = Math.max(0.001, size.y);
        const unitFootprint = Math.max(0.001, size.x, size.z);
        gltf.scene.traverse(node => {
            if (!node.isMesh || !node.geometry || !node.material) return;
            const mesh = new THREE.InstancedMesh(node.geometry, node.material, placements.length);
            mesh.name = `Biome:${assetId}:${node.name || 'mesh'}`;
            mesh.userData.renderIds = placements.map(row => row.renderId);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            for (let index = 0; index < placements.length; index++) {
                const row = placements[index];
                // Trees normalize by height; broad rocks normalize by footprint.
                // The latter prevents a naturally squat boulder from becoming a
                // six-hex mesa merely because its Y extent is small.
                const scale = row.desiredHeight / (row.kind === 'MOUNTAIN' ? unitFootprint : unitHeight);
                placementMatrix.makeTranslation(row.x, row.y, row.z);
                rotationMatrix.makeRotationY(row.rotationY);
                scaleMatrix.makeScale(scale, scale, scale);
                anchorMatrix.makeTranslation(-center.x, -bounds.min.y, -center.z);
                const matrix = new THREE.Matrix4().multiplyMatrices(placementMatrix, rotationMatrix)
                    .multiply(scaleMatrix).multiply(anchorMatrix).multiply(node.matrixWorld);
                mesh.setMatrixAt(index, matrix);
            }
            mesh.instanceMatrix.needsUpdate = true;
            layer.add(mesh);
        });
    }
    terrainRoot.add(layer);
    state.biomeLayer = layer;
    updateLod();
    requestRender();
}

async function installSettlementLayer(plan, snapshot, terrainRoot) {
    if (typeof window.story3DSettlementsCompile !== 'function') return;
    const settlementPlan = window.story3DSettlementsCompile(plan, snapshot, state.surfacePlan);
    const validation = window.story3DSettlementsValidate?.(
        settlementPlan, plan, snapshot, state.surfacePlan);
    if (validation && !validation.ok) {
        throw new Error(`3D settlement invalid: ${validation.issues.join(',')}`);
    }
    state.settlementPlan = settlementPlan;
    if (!settlementPlan.placements.length) return;
    const loaded = new Map();
    await Promise.all(Object.keys(settlementPlan.byAsset).map(async assetId => {
        loaded.set(assetId, await loadGLTF(settlementPlan.assets[assetId]));
    }));
    if (state.terrainRoot !== terrainRoot || state.terrainStaticHash !== plan.sourceStaticHash) return;
    const layer = new THREE.Group();
    layer.name = 'LOD:NEAR_MID:SettlementAssets';
    const placementMatrix = new THREE.Matrix4();
    const rotationMatrix = new THREE.Matrix4();
    const scaleMatrix = new THREE.Matrix4();
    const anchorMatrix = new THREE.Matrix4();
    for (const [assetId, placements] of Object.entries(settlementPlan.byAsset)) {
        const gltf = loaded.get(assetId);
        gltf.scene.updateMatrixWorld(true);
        const bounds = new THREE.Box3().setFromObject(gltf.scene);
        const size = bounds.getSize(new THREE.Vector3());
        const center = bounds.getCenter(new THREE.Vector3());
        const footprint = Math.max(0.001, size.x, size.z);
        gltf.scene.traverse(node => {
            if (!node.isMesh || !node.geometry || !node.material) return;
            const mesh = new THREE.InstancedMesh(node.geometry, node.material, placements.length);
            mesh.name = `Settlement:${assetId}:${node.name || 'mesh'}`;
            mesh.userData.renderIds = placements.map(row => row.renderId);
            mesh.userData.sourceRenderIds = placements.map(row => row.sourceRenderId);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            for (let index = 0; index < placements.length; index++) {
                const row = placements[index];
                const scale = row.desiredFootprint / footprint;
                placementMatrix.makeTranslation(row.x, row.y, row.z);
                rotationMatrix.makeRotationY(row.rotationY);
                scaleMatrix.makeScale(scale, scale, scale);
                anchorMatrix.makeTranslation(-center.x, -bounds.min.y, -center.z);
                const matrix = new THREE.Matrix4().multiplyMatrices(placementMatrix, rotationMatrix)
                    .multiply(scaleMatrix).multiply(anchorMatrix).multiply(node.matrixWorld);
                mesh.setMatrixAt(index, matrix);
            }
            mesh.instanceMatrix.needsUpdate = true;
            layer.add(mesh);
        });
    }
    terrainRoot.add(layer);
    state.settlementLayer = layer;
    installCityLabels(settlementPlan, snapshot);
    updateLod();
    requestRender();
}

function installCityLabels(settlementPlan, snapshot) {
    if (!state.labelLayer || !THREE) return;
    state.labelLayer.replaceChildren();
    state.cityLabels = [];
    const coreBySource = new Map();
    for (const placement of settlementPlan.placements) {
        if (placement.kind !== 'CITY_CORE' || !placement.renderId.endsWith(':0')) continue;
        coreBySource.set(placement.sourceRenderId, placement);
    }
    for (const city of snapshot.static.settlements || []) {
        const core = coreBySource.get(city.renderId);
        if (!core) continue;
        const label = document.createElement('div');
        label.className = 'story3d-city-label';
        label.dataset.tier = String(core.tier);
        const name = document.createElement('strong');
        name.textContent = String(city.name || 'ŞEHİR').toLocaleUpperCase('tr-TR');
        const meta = document.createElement('small');
        const population = Math.max(0, Number(city.populationPeople) || 0);
        meta.textContent = population >= 1000000
            ? `${(population / 1000000).toFixed(1)} MN`
            : `${Math.max(1, Math.round(population / 1000))} BİN`;
        label.append(name, meta);
        state.labelLayer.append(label);
        state.cityLabels.push({
            element: label,
            world: new THREE.Vector3(core.x, core.y + 1.1 + core.tier * 0.12, core.z)
        });
    }
    updateCityLabels();
}

function updateCityLabels() {
    if (!state.canvas || !state.camera || !state.cityLabels.length) return;
    const width = state.canvas.clientWidth || 1;
    const height = state.canvas.clientHeight || 1;
    for (const entry of state.cityLabels) {
        const projected = entry.world.clone().project(state.camera);
        const visible = projected.z >= -1 && projected.z <= 1
            && projected.x >= -1.08 && projected.x <= 1.08
            && projected.y >= -1.08 && projected.y <= 1.08;
        entry.element.hidden = !visible;
        if (!visible) continue;
        entry.element.style.transform = `translate3d(${(projected.x * 0.5 + 0.5) * width}px,${(-projected.y * 0.5 + 0.5) * height}px,0) translate(-50%,-115%)`;
    }
}

async function installInfrastructureLayer(plan, snapshot, terrainRoot) {
    if (typeof window.story3DInfrastructureCompile !== 'function') return;
    const infraPlan = window.story3DInfrastructureCompile(plan, snapshot, state.surfacePlan);
    const validation = window.story3DInfrastructureValidate?.(
        infraPlan, plan, snapshot, state.surfacePlan);
    if (validation && !validation.ok) {
        throw new Error(`3D infrastructure invalid: ${validation.issues.join(',')}`);
    }
    state.infrastructurePlan = infraPlan;
    if (!infraPlan.placements.length) return;
    const loaded = new Map();
    await Promise.all(Object.keys(infraPlan.byAsset).map(async assetId => {
        loaded.set(assetId, await loadGLTF(infraPlan.assets[assetId]));
    }));
    if (state.terrainRoot !== terrainRoot || state.terrainStaticHash !== plan.sourceStaticHash) return;
    const layer = new THREE.Group();
    layer.name = 'LOD:NEAR_MID:InfrastructureAssets';
    const placementMatrix = new THREE.Matrix4();
    const yawMatrix = new THREE.Matrix4();
    const pitchMatrix = new THREE.Matrix4();
    const scaleMatrix = new THREE.Matrix4();
    const anchorMatrix = new THREE.Matrix4();
    for (const [assetId, placements] of Object.entries(infraPlan.byAsset)) {
        const gltf = loaded.get(assetId);
        gltf.scene.updateMatrixWorld(true);
        const bounds = new THREE.Box3().setFromObject(gltf.scene);
        const size = bounds.getSize(new THREE.Vector3());
        const center = bounds.getCenter(new THREE.Vector3());
        gltf.scene.traverse(node => {
            if (!node.isMesh || !node.geometry || !node.material) return;
            const roadMaterial = node.material.clone();
            if (roadMaterial.color) roadMaterial.color.multiply(new THREE.Color(0x9d947d));
            roadMaterial.roughness = 0.9;
            roadMaterial.metalness = 0.0;
            const mesh = new THREE.InstancedMesh(node.geometry, roadMaterial, placements.length);
            mesh.name = `Infrastructure:${assetId}:${node.name || 'mesh'}`;
            mesh.userData.renderIds = placements.map(row => row.renderId);
            mesh.userData.sourceRenderIds = placements.map(row => row.sourceRenderId);
            mesh.castShadow = true;
            mesh.receiveShadow = true;
            for (let index = 0; index < placements.length; index++) {
                const row = placements[index];
                const scaleX = row.desiredWidth / Math.max(0.001, size.x);
                const scaleY = scaleX;
                const scaleZ = row.desiredLength / Math.max(0.001, size.z);
                placementMatrix.makeTranslation(row.x, row.y, row.z);
                yawMatrix.makeRotationY(row.rotationY);
                pitchMatrix.makeRotationX(-row.pitch);
                scaleMatrix.makeScale(scaleX, scaleY, scaleZ);
                anchorMatrix.makeTranslation(-center.x, -bounds.min.y, -center.z);
                const matrix = new THREE.Matrix4().multiplyMatrices(placementMatrix, yawMatrix)
                    .multiply(pitchMatrix).multiply(scaleMatrix).multiply(anchorMatrix)
                    .multiply(node.matrixWorld);
                mesh.setMatrixAt(index, matrix);
            }
            mesh.instanceMatrix.needsUpdate = true;
            layer.add(mesh);
        });
    }
    terrainRoot.add(layer);
    state.infrastructureLayer = layer;
    updateLod();
    requestRender();
}

async function installWorldAssetLayers(plan, snapshot, terrainRoot) {
    state.assetStatus = 'LOADING';
    state.assetError = null;
    await installBiomeLayer(plan, snapshot, terrainRoot);
    await installInfrastructureLayer(plan, snapshot, terrainRoot);
    await installSettlementLayer(plan, snapshot, terrainRoot);
    if (state.terrainRoot !== terrainRoot || state.terrainStaticHash !== plan.sourceStaticHash) return;
    state.assetStatus = 'READY';
    updateLod();
    requestRender();
}

function installTerrain(plan, snapshot) {
    clearTerrain();
    const root = new THREE.Group();
    root.name = 'CanonicalHexTerrain';
    if (typeof window.story3DSurfaceCompile !== 'function') throw new Error('3D surface compiler bulunamadı');
    const surface = window.story3DSurfaceCompile(plan);
    const validation = window.story3DSurfaceValidate?.(surface, plan);
    if (validation && !validation.ok) throw new Error(`3D surface invalid: ${validation.issues.join(',')}`);
    const landSurface = new THREE.Mesh(
        makeSurfaceGeometry(surface.positions, surface.colors, surface.landIndices),
        new THREE.MeshStandardMaterial({
            vertexColors: true, side: THREE.DoubleSide, roughness: 0.94,
            metalness: 0.0, normalMap: state.terrainTextures?.normal || null,
            normalScale: new THREE.Vector2(0.18, 0.18)
        }));
    landSurface.name = 'TerrainContinuousSurface';
    landSurface.userData.cellRanges = surface.cellRanges;
    landSurface.receiveShadow = true;
    root.add(landSurface);
    const waterSurface = new THREE.Mesh(
        makeSurfaceGeometry(surface.positions, surface.colors, surface.waterIndices),
        new THREE.MeshPhysicalMaterial({
            vertexColors: true, side: THREE.DoubleSide, roughness: 0.24,
            metalness: 0.08, clearcoat: 0.55, clearcoatRoughness: 0.28
        }));
    waterSurface.name = 'TerrainWaterSurface';
    waterSurface.receiveShadow = true;
    root.add(waterSurface);
    let shore = null;
    if (surface.shoreIndices.length) {
        shore = new THREE.Mesh(makeSurfaceGeometry(surface.shorePositions, surface.shoreColors, surface.shoreIndices),
            new THREE.MeshStandardMaterial({
                vertexColors: true, side: THREE.DoubleSide, roughness: 0.88,
                metalness: 0.0
            }));
        shore.name = 'TerrainCoastSkirt'; root.add(shore);
    }
    state.surfacePlan = surface;
    const matrix = new THREE.Matrix4();
    const position = new THREE.Vector3();
    const rotation = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI / 6);
    const scale = new THREE.Vector3();
    const allInstances = ['WATER', 'LAND', 'COAST', 'MOUNTAIN'].flatMap(type => plan.groups[type]);
    const overlayGeometry = new THREE.CylinderGeometry(0.92, 0.92, 1, 6, 1, false);
    const overlayMaterial = new THREE.MeshBasicMaterial({ vertexColors: false,
        transparent: true, opacity: 0.22, depthWrite: false, polygonOffset: true,
        polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    const overlay = new THREE.InstancedMesh(overlayGeometry, overlayMaterial, allInstances.length);
    overlay.name = 'PoliticalOverlay';
    overlay.userData.renderIds = allInstances.map(row => row.renderId);
    for (let index = 0; index < allInstances.length; index++) {
        const row = allInstances[index];
        position.set(row.x, (surface.cellHeights[row.renderId] || 0.72) + 0.025, row.z);
        scale.set(1, 0.035, 1);
        matrix.compose(position, rotation, scale);
        overlay.setMatrixAt(index, matrix);
        overlay.setColorAt(index, ownerColor(row.ownerId));
    }
    overlay.instanceMatrix.needsUpdate = true;
    if (overlay.instanceColor) overlay.instanceColor.needsUpdate = true;
    root.add(overlay);
    state.politicalOverlay = overlay;

    const coastNear = new THREE.Group();
    coastNear.name = 'LOD:NEAR:CoastFutureDetail';
    root.add(coastNear);
    state.detailLayers = { coast: shore || new THREE.Group(), coastNear };
    state.scene.add(root);
    state.terrainRoot = root;
    state.terrainPlan = plan;
    state.terrainStaticHash = plan.sourceStaticHash;
    const shell = state.canvas?.parentElement;
    const aspect = Math.max(0.5, (shell?.clientWidth || 1) / Math.max(1, shell?.clientHeight || 1));
    state.viewHeight = Math.max(plan.bounds.depth, plan.bounds.width / aspect) * 1.18;
    state.fitViewHeight = state.viewHeight;
    state.cameraTarget.set(0, 0, 0);
    state.camera.position.set(0, Math.max(24, state.viewHeight * 0.78), state.viewHeight * 0.88);
    state.camera.lookAt(state.cameraTarget);
    updateLod();
    resize();
    state.status = STATUS.READY_WORLD;
    state.reason = null;
    requestRender();
    installWorldAssetLayers(plan, snapshot, root).catch(error => {
        state.assetStatus = 'ERROR';
        state.assetError = String(error?.message || error);
        requestRender();
    });
}

function groundPoint(event) {
    if (!state.canvas || !state.camera) return null;
    const rect = state.canvas.getBoundingClientRect();
    const pointer = new THREE.Vector2(
        (event.clientX - rect.left) / Math.max(1, rect.width) * 2 - 1,
        -((event.clientY - rect.top) / Math.max(1, rect.height)) * 2 + 1
    );
    const raycaster = new THREE.Raycaster();
    raycaster.setFromCamera(pointer, state.camera);
    return raycaster.ray.intersectPlane(new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), new THREE.Vector3());
}

function clampCameraTarget() {
    const bounds = state.terrainPlan?.bounds;
    if (!bounds) return;
    state.cameraTarget.x = THREE.MathUtils.clamp(state.cameraTarget.x, bounds.minX, bounds.maxX);
    state.cameraTarget.z = THREE.MathUtils.clamp(state.cameraTarget.z, bounds.minZ, bounds.maxZ);
}

function attachCameraControls() {
    state.inputAbort?.abort();
    state.inputAbort = new AbortController();
    const signal = state.inputAbort.signal;
    let drag = null;
    state.canvas.style.touchAction = 'none';
    state.canvas.addEventListener('pointerdown', event => {
        if (event.button !== 0) return;
        drag = { pointerId: event.pointerId, point: groundPoint(event) };
        state.canvas.setPointerCapture(event.pointerId);
    }, { signal });
    state.canvas.addEventListener('pointermove', event => {
        if (!drag || drag.pointerId !== event.pointerId || !drag.point) return;
        const current = groundPoint(event);
        if (!current) return;
        const delta = drag.point.clone().sub(current);
        delta.y = 0;
        state.camera.position.add(delta);
        state.cameraTarget.add(delta);
        clampCameraTarget();
        state.camera.lookAt(state.cameraTarget);
        drag.point = groundPoint(event);
        requestRender();
    }, { signal });
    const endDrag = event => {
        if (drag?.pointerId === event.pointerId) drag = null;
    };
    state.canvas.addEventListener('pointerup', endDrag, { signal });
    state.canvas.addEventListener('pointercancel', endDrag, { signal });
    state.canvas.addEventListener('wheel', event => {
        event.preventDefault();
        const before = groundPoint(event);
        const next = THREE.MathUtils.clamp(state.viewHeight * Math.exp(event.deltaY * 0.0014),
            10, Math.max(12, state.fitViewHeight * 1.45));
        state.viewHeight = next;
        resize();
        const after = groundPoint(event);
        if (before && after) {
            const delta = before.sub(after); delta.y = 0;
            state.camera.position.add(delta);
            state.cameraTarget.add(delta);
            clampCameraTarget();
            state.camera.lookAt(state.cameraTarget);
        }
        updateLod();
        requestRender();
    }, { passive: false, signal });
    window.addEventListener('keydown', event => {
        if (event.key.toLowerCase() !== 'p') return;
        const target = event.target;
        if (target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName || ''))) return;
        state.politicalEnabled = !state.politicalEnabled;
        updateLod();
        requestRender();
    }, { signal });
}

function refreshTerrain() {
    if (state.active !== '3d' || typeof window.story3DProjectionSnapshot !== 'function'
        || typeof window.story3DTerrainCompile !== 'function') return false;
    try {
        const snapshot = window.story3DProjectionSnapshot();
        if (snapshot.static.staticHash === state.terrainStaticHash) return true;
        const plan = window.story3DTerrainCompile(snapshot, { chunkSize: 16 });
        const validation = window.story3DTerrainValidate?.(plan, snapshot);
        if (validation && !validation.ok) throw new Error('3D terrain validation failed');
        installTerrain(plan, snapshot);
        return true;
    } catch (error) {
        state.reason = `Arazi bekliyor: ${error?.message || error}`;
        return false;
    }
}

function renderFrame() {
    state.frameHandle = 0;
    if (state.active !== '3d' || !state.renderer) return;
    state.renderer.render(state.scene, state.camera);
    updateCityLabels();
    state.frameCount += 1;
    updateDiagnosticsElement();
}

function updateDiagnosticsElement() {
    if (!state.diagnosticsElement) return;
    const diag = publicSnapshot();
    state.diagnosticsElement.innerHTML = `<b>3D PROTOTİP · ${diag.lod}</b>`
        + `<span>${diag.terrainInstances} HEX · ${diag.renderCalls} DRAW · ${diag.triangles.toLocaleString('tr-TR')} ÜÇGEN</span>`
        + `<small>SÜRÜKLE · TEKERLEK · P: POLİTİK ${diag.politicalOverlay ? 'AÇIK' : 'KAPALI'}</small>`;
}

function requestRender() {
    if (!state.frameHandle && state.active === '3d') state.frameHandle = requestAnimationFrame(renderFrame);
}

function dispose({ keepFallback = true } = {}) {
    if (state.frameHandle) cancelAnimationFrame(state.frameHandle);
    state.frameHandle = 0;
    state.resizeObserver?.disconnect();
    state.resizeObserver = null;
    state.screenObserver?.disconnect();
    state.screenObserver = null;
    state.inputAbort?.abort();
    state.inputAbort = null;
    state.diagnosticsElement?.remove();
    state.diagnosticsElement = null;
    state.labelLayer?.remove();
    state.labelLayer = null;
    state.cityLabels = [];
    state.renderer?.dispose();
    state.renderer = null;
    state.terrainTextures?.normal?.dispose?.();
    state.terrainTextures = null;
    clearTerrain();
    state.scene = null;
    state.camera = null;
    if (state.canvas) {
        state.canvas.remove();
        state.canvas = null;
    }
    state.active = '2d';
    state.status = STATUS.DISPOSED;
    if (keepFallback) document.body.removeAttribute('data-story-renderer');
}

async function boot() {
    if (state.requested !== '3d') return publicSnapshot();
    state.status = STATUS.BOOTING;
    try {
        THREE = await import(THREE_MODULE_PATH);
        ({ GLTFLoader: GLTFLoaderClass } = await import('../node_modules/three/examples/jsm/loaders/GLTFLoader.js'));
        state.cameraTarget = new THREE.Vector3();
    } catch (error) {
        show2DFallback(`Three.js yüklenemedi: ${error?.message || error}`);
        return publicSnapshot();
    }
    const shell = document.getElementById('story-map-shell');
    if (!shell) {
        show2DFallback('story-map-shell bulunamadı');
        return publicSnapshot();
    }

    const canvas = document.createElement('canvas');
    canvas.id = 'storyCanvas3D';
    canvas.setAttribute('aria-label', '3D hikâye dünya haritası');
    canvas.hidden = true;
    shell.prepend(canvas);
    state.canvas = canvas;
    const diagnostics = document.createElement('div');
    diagnostics.id = 'story3d-diagnostics';
    diagnostics.setAttribute('aria-live', 'polite');
    shell.append(diagnostics);
    state.diagnosticsElement = diagnostics;
    const labelLayer = document.createElement('div');
    labelLayer.id = 'story3d-label-layer';
    labelLayer.setAttribute('aria-hidden', 'true');
    shell.append(labelLayer);
    state.labelLayer = labelLayer;

    const context = canvas.getContext('webgl2', {
        alpha: false,
        antialias: true,
        depth: true,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: false,
    });
    if (!context) {
        show2DFallback('WebGL2 bağlamı oluşturulamadı');
        return publicSnapshot();
    }

    canvas.addEventListener('webglcontextlost', event => {
        event.preventDefault();
        show2DFallback('WebGL bağlamı kayboldu', STATUS.CONTEXT_LOST);
    }, false);

    try {
        state.renderer = new THREE.WebGLRenderer({ canvas, context, antialias: true, alpha: false });
        state.renderer.outputColorSpace = THREE.SRGBColorSpace;
        state.renderer.toneMapping = THREE.ACESFilmicToneMapping;
        state.renderer.toneMappingExposure = 1.08;
        state.renderer.shadowMap.enabled = true;
        state.renderer.shadowMap.type = THREE.PCFShadowMap;
        state.renderer.setClearColor(0x17313a, 1);
        state.scene = new THREE.Scene();
        state.scene.background = new THREE.Color(0x17313a);
        state.scene.fog = new THREE.Fog(0x8fa9a1, 62, 122);
        state.camera = new THREE.OrthographicCamera(-50, 50, 50, -50, 0.1, 1000);
        state.camera.position.set(0, 80, 80);
        state.camera.lookAt(0, 0, 0);
        state.scene.add(new THREE.HemisphereLight(0xdceaf2, 0x26351f, 1.15));
        // Stilize strateji haritasında hücre bilgisi sinematik karanlığa kurban
        // edilemez. Yönlü ışık biçim verir; ambient taban okunurluğu garanti eder.
        state.scene.add(new THREE.AmbientLight(0xffffff, 0.5));
        const sun = new THREE.DirectionalLight(0xffe0ad, 3.25);
        sun.position.set(-28, 48, 24);
        sun.castShadow = true;
        sun.shadow.mapSize.set(2048, 2048);
        sun.shadow.camera.left = -64;
        sun.shadow.camera.right = 64;
        sun.shadow.camera.top = 64;
        sun.shadow.camera.bottom = -64;
        sun.shadow.camera.near = 1;
        sun.shadow.camera.far = 160;
        sun.shadow.bias = -0.00035;
        state.scene.add(sun);
        const terrainTextureLoader = new THREE.TextureLoader();
        const terrainNormal = await terrainTextureLoader.loadAsync(
            'assets/vendor/polyhaven-aerial-grass-rock/aerial_grass_rock_nor_gl_1k.jpg');
        terrainNormal.wrapS = THREE.RepeatWrapping;
        terrainNormal.wrapT = THREE.RepeatWrapping;
        terrainNormal.anisotropy = Math.min(8, state.renderer.capabilities.getMaxAnisotropy());
        state.terrainTextures = { normal: terrainNormal };
        resize();
        state.resizeObserver = new ResizeObserver(() => { resize(); requestRender(); });
        state.resizeObserver.observe(shell);
        await state.renderer.compileAsync(state.scene, state.camera);
        canvas.hidden = false;
        document.body.dataset.storyRenderer = '3d';
        state.active = '3d';
        state.status = STATUS.READY_SHELL;
        state.reason = null;
        requestRender();
        attachCameraControls();
        refreshTerrain();
        // Başlık ekranında politik/şehir kayıtları henüz kurulmamış olabilir.
        // Kampanya ekranı gerçekten açıldığında aynı kanonik snapshot yeniden istenir.
        state.screenObserver = new MutationObserver(() => {
            if (document.body.getAttribute('data-screen') === 'story') refreshTerrain();
        });
        state.screenObserver.observe(document.body, { attributes: true, attributeFilter: ['data-screen'] });
    } catch (error) {
        show2DFallback(error?.message || 'Three.js başlatılamadı');
    }
    return publicSnapshot();
}

window.Story3D = Object.freeze({
    version: 'HXD-9C.1',
    STATUS,
    boot,
    requestRender,
    refreshTerrain,
    setPoliticalOverlay(visible) {
        if (!state.politicalOverlay) return false;
        state.politicalEnabled = visible !== false;
        state.politicalOverlay.visible = state.politicalEnabled;
        requestRender();
        return state.politicalOverlay.visible;
    },
    diagnostics: publicSnapshot,
    setViewScale(scale) {
        if (!state.fitViewHeight || state.active !== '3d') return false;
        const factor = THREE.MathUtils.clamp(Number(scale) || 1, 0.24, 1.45);
        state.viewHeight = state.fitViewHeight * factor;
        updateLod();
        resize();
        requestRender();
        return true;
    },
    dispose,
});

await boot();
