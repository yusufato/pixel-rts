'use strict';

// HXD-9C.2d — canonical city/district projection -> deterministic 3D placement.
// This layer reads simulation truth but never creates population, buildings,
// ownership or technology. Missing future-era art is reported as catalog debt.
const STORY_3D_SETTLEMENT_SCHEMA_VERSION = 2;
const STORY_3D_SETTLEMENT_ASSETS = Object.freeze({
    COMMERCIAL_A: 'assets/vendor/kenney-city-commercial/glb/building-a.glb',
    COMMERCIAL_B: 'assets/vendor/kenney-city-commercial/glb/building-b.glb',
    COMMERCIAL_C: 'assets/vendor/kenney-city-commercial/glb/building-c.glb',
    COMMERCIAL_D: 'assets/vendor/kenney-city-commercial/glb/building-d.glb',
    COMMERCIAL_E: 'assets/vendor/kenney-city-commercial/glb/building-e.glb',
    COMMERCIAL_F: 'assets/vendor/kenney-city-commercial/glb/building-f.glb',
    COMMERCIAL_G: 'assets/vendor/kenney-city-commercial/glb/building-g.glb',
    SKYSCRAPER_A: 'assets/vendor/kenney-city-commercial/glb/building-skyscraper-a.glb',
    SKYSCRAPER_B: 'assets/vendor/kenney-city-commercial/glb/building-skyscraper-b.glb',
    SKYSCRAPER_C: 'assets/vendor/kenney-city-commercial/glb/building-skyscraper-c.glb',
    SKYSCRAPER_D: 'assets/vendor/kenney-city-commercial/glb/building-skyscraper-d.glb',
    SKYSCRAPER_E: 'assets/vendor/kenney-city-commercial/glb/building-skyscraper-e.glb',
    SUBURBAN_A: 'assets/vendor/kenney-city-suburban/glb/building-type-a.glb',
    SUBURBAN_B: 'assets/vendor/kenney-city-suburban/glb/building-type-b.glb',
    SUBURBAN_C: 'assets/vendor/kenney-city-suburban/glb/building-type-c.glb',
    SUBURBAN_D: 'assets/vendor/kenney-city-suburban/glb/building-type-d.glb',
    SUBURBAN_F: 'assets/vendor/kenney-city-suburban/glb/building-type-f.glb',
    SUBURBAN_G: 'assets/vendor/kenney-city-suburban/glb/building-type-g.glb',
    SUBURBAN_H: 'assets/vendor/kenney-city-suburban/glb/building-type-h.glb',
    SUBURBAN_I: 'assets/vendor/kenney-city-suburban/glb/building-type-i.glb',
    SUBURBAN_J: 'assets/vendor/kenney-city-suburban/glb/building-type-j.glb',
    SUBURBAN_K: 'assets/vendor/kenney-city-suburban/glb/building-type-k.glb',
    SUBURBAN_L: 'assets/vendor/kenney-city-suburban/glb/building-type-l.glb',
    SUBURBAN_M: 'assets/vendor/kenney-city-suburban/glb/building-type-m.glb',
    SUBURBAN_N: 'assets/vendor/kenney-city-suburban/glb/building-type-n.glb',
    INDUSTRIAL_A: 'assets/vendor/kenney-city-industrial/glb/building-a.glb',
    INDUSTRIAL_B: 'assets/vendor/kenney-city-industrial/glb/building-b.glb',
    INDUSTRIAL_C: 'assets/vendor/kenney-city-industrial/glb/building-c.glb',
    INDUSTRIAL_D: 'assets/vendor/kenney-city-industrial/glb/building-d.glb',
    INDUSTRIAL_E: 'assets/vendor/kenney-city-industrial/glb/building-e.glb',
    INDUSTRIAL_F: 'assets/vendor/kenney-city-industrial/glb/building-f.glb',
    INDUSTRIAL_G: 'assets/vendor/kenney-city-industrial/glb/building-g.glb',
    INDUSTRIAL_H: 'assets/vendor/kenney-city-industrial/glb/building-h.glb',
    INDUSTRIAL_I: 'assets/vendor/kenney-city-industrial/glb/building-i.glb',
    INDUSTRIAL_J: 'assets/vendor/kenney-city-industrial/glb/building-j.glb',
    INDUSTRIAL_L: 'assets/vendor/kenney-city-industrial/glb/building-l.glb',
    INDUSTRIAL_TANK: 'assets/vendor/kenney-city-industrial/glb/detail-tank.glb'
});

function story3DSettlementHash(text) {
    let value = 2166136261;
    for (const char of String(text)) {
        value ^= char.charCodeAt(0);
        value = Math.imul(value, 16777619);
    }
    return value >>> 0;
}
function story3DSettlementTier(row) {
    const population = Math.max(0, Number(row.populationPeople) || 0);
    const level = Math.max(1, Number(row.level) || 1);
    if (population >= 500000 || level >= 5) return 3;
    if (population >= 150000 || level >= 4) return 2;
    if (population >= 50000 || level >= 2) return 1;
    return 0;
}
function story3DSettlementEra(year) {
    const value = Number(year) || 2032;
    if (value >= 2070) return 'FUTURE_2070_2100';
    if (value >= 2040) return 'TRANSITION_2040_2069';
    return 'MODERN_2010_2039';
}
function story3DSettlementAsset(kind, seed, tier) {
    const choose = list => list[seed % list.length];
    if (kind === 'RESIDENTIAL') return choose(['SUBURBAN_A', 'SUBURBAN_B', 'SUBURBAN_C',
        'SUBURBAN_D', 'SUBURBAN_F', 'SUBURBAN_G', 'SUBURBAN_H', 'SUBURBAN_I',
        'SUBURBAN_J', 'SUBURBAN_K', 'SUBURBAN_L', 'SUBURBAN_M', 'SUBURBAN_N']);
    if (kind === 'INDUSTRIAL') return choose(['INDUSTRIAL_A', 'INDUSTRIAL_B', 'INDUSTRIAL_C',
        'INDUSTRIAL_D', 'INDUSTRIAL_E', 'INDUSTRIAL_F', 'INDUSTRIAL_G',
        'INDUSTRIAL_H', 'INDUSTRIAL_I', 'INDUSTRIAL_J']);
    if (kind === 'DEFENSE') return choose(['INDUSTRIAL_L', 'INDUSTRIAL_H', 'INDUSTRIAL_J']);
    if (kind === 'LOGISTICS') return choose(['INDUSTRIAL_A', 'INDUSTRIAL_D',
        'INDUSTRIAL_G', 'INDUSTRIAL_TANK']);
    if (tier >= 3) return choose(['SKYSCRAPER_A', 'SKYSCRAPER_B', 'SKYSCRAPER_C',
        'SKYSCRAPER_D', 'SKYSCRAPER_E']);
    return choose(['COMMERCIAL_A', 'COMMERCIAL_B', 'COMMERCIAL_C', 'COMMERCIAL_D',
        'COMMERCIAL_E', 'COMMERCIAL_F', 'COMMERCIAL_G']);
}

function story3DSettlementsCompile(plan, snapshot, surface) {
    if (!plan || plan.rendererAuthority !== 'READ_ONLY') throw new Error('STORY_3D_SETTLEMENT_TERRAIN_PLAN_REQUIRED');
    if (!snapshot?.static) throw new Error('STORY_3D_SETTLEMENT_PROJECTION_REQUIRED');
    const cells = new Map();
    for (const row of ['WATER', 'LAND', 'COAST', 'MOUNTAIN'].flatMap(type => plan.groups[type] || [])) {
        cells.set(row.cellIndex, row);
    }
    const placements = [];
    const visualEra = story3DSettlementEra(snapshot.dynamic?.year);
    const futureCatalogFallback = visualEra === 'MODERN_2010_2039' ? 0 : 1;
    for (const city of snapshot.static.settlements || []) {
        const cell = cells.get(city.coreCellIndex);
        if (!cell || cell.type === 'WATER') continue;
        const tier = story3DSettlementTier(city);
        // A city is read as an urban cluster, not one oversized map marker.
        // Population tier controls visual module density without inventing
        // simulation buildings or changing city capacity.
        const count = Math.min(12, 6 + tier * 2);
        const y = Number(surface?.cellHeights?.[cell.renderId]) || 0.72;
        for (let slot = 0; slot < count; slot++) {
            const seed = story3DSettlementHash(`${city.renderId}:${slot}`);
            const ring = slot === 0 ? 0 : slot <= 6 ? 1 : 2;
            const ringSlot = ring === 1 ? slot - 1 : slot - 7;
            const ringCount = ring === 1 ? Math.min(6, count - 1) : Math.max(1, count - 7);
            const angle = ring === 0 ? 0 : ringSlot / ringCount * Math.PI * 2 + (seed % 19) / 120;
            const distance = ring === 0 ? 0 : ring === 1 ? 0.31 : 0.53;
            const assetId = story3DSettlementAsset('CORE', seed, tier);
            placements.push(Object.freeze({
                kind: 'CITY_CORE', districtKind: 'CORE', assetId,
                renderId: `settlement:${city.nodeId}:core:${slot}`,
                sourceRenderId: city.renderId, cellIndex: cell.cellIndex, cellRenderId: cell.renderId,
                nodeId: city.nodeId, ownerId: city.ownerId, tier, visualEra,
                x: cell.x + Math.cos(angle) * distance, y, z: cell.z + Math.sin(angle) * distance,
                rotationY: angle + Math.PI / 6,
                desiredFootprint: slot === 0 ? 0.92 + tier * 0.06
                    : ring === 1 ? 0.46 + tier * 0.022 : 0.36 + tier * 0.018
            }));
        }
    }
    for (const district of snapshot.static.districts || []) {
        if (district.kind === 'CORE') continue;
        const cell = cells.get(district.cellIndex);
        if (!cell || cell.type === 'WATER') continue;
        const tier = story3DSettlementTier(district);
        const count = district.kind === 'RESIDENTIAL' ? 3 : 2;
        const y = Number(surface?.cellHeights?.[cell.renderId]) || 0.72;
        for (let slot = 0; slot < count; slot++) {
            const seed = story3DSettlementHash(`${district.renderId}:${slot}`);
            const angle = (seed % 360) * Math.PI / 180;
            const distance = count === 1 ? 0 : 0.25;
            placements.push(Object.freeze({
                kind: 'DISTRICT', districtKind: district.kind,
                assetId: story3DSettlementAsset(district.kind, seed, tier),
                renderId: `settlement:${district.renderId}:${slot}`,
                sourceRenderId: district.renderId, cellIndex: cell.cellIndex, cellRenderId: cell.renderId,
                nodeId: district.nodeId, ownerId: district.ownerId, tier, visualEra,
                x: cell.x + Math.cos(angle) * distance, y, z: cell.z + Math.sin(angle) * distance,
                rotationY: angle,
                desiredFootprint: district.kind === 'RESIDENTIAL' ? 0.43 : 0.56
            }));
        }
    }
    const byAsset = {};
    for (const placement of placements) {
        if (!byAsset[placement.assetId]) byAsset[placement.assetId] = [];
        byAsset[placement.assetId].push(placement);
    }
    for (const rows of Object.values(byAsset)) Object.freeze(rows);
    return Object.freeze({
        schemaVersion: STORY_3D_SETTLEMENT_SCHEMA_VERSION,
        sourceStaticHash: plan.sourceStaticHash,
        sourceSurfaceHash: surface?.sourceStaticHash || null,
        rendererAuthority: 'READ_ONLY_VISUALIZATION',
        visualEra, assets: STORY_3D_SETTLEMENT_ASSETS,
        placements: Object.freeze(placements), byAsset: Object.freeze(byAsset),
        diagnostics: Object.freeze({
            placementCount: placements.length,
            cityCoreCount: placements.filter(row => row.kind === 'CITY_CORE').length,
            districtCount: placements.filter(row => row.kind === 'DISTRICT').length,
            assetCount: Object.keys(byAsset).length,
            futureCatalogFallback
        })
    });
}

function story3DSettlementsValidate(result, plan, snapshot, surface) {
    const issues = [];
    if (!result || result.schemaVersion !== STORY_3D_SETTLEMENT_SCHEMA_VERSION) issues.push('SCHEMA');
    if (result && plan && result.sourceStaticHash !== plan.sourceStaticHash) issues.push('SOURCE_HASH');
    if (result && surface && result.sourceSurfaceHash !== surface.sourceStaticHash) issues.push('SURFACE_HASH');
    if (result && new Set(result.placements.map(row => row.renderId)).size !== result.placements.length) issues.push('DUPLICATE_ID');
    if (result && result.placements.some(row => !result.assets[row.assetId])) issues.push('UNKNOWN_ASSET');
    if (result && surface && result.placements.some(row => row.y !== surface.cellHeights[row.cellRenderId])) issues.push('SURFACE_HEIGHT');
    const sourceIds = new Set([...(snapshot?.static?.settlements || []), ...(snapshot?.static?.districts || [])].map(row => row.renderId));
    if (result && result.placements.some(row => !sourceIds.has(row.sourceRenderId))) issues.push('SOURCE_ID');
    return Object.freeze({ ok: issues.length === 0, issues: Object.freeze(issues) });
}

if (typeof window !== 'undefined') {
    window.story3DSettlementsCompile = story3DSettlementsCompile;
    window.story3DSettlementsValidate = story3DSettlementsValidate;
}
if (typeof module !== 'undefined' && module.exports) module.exports = {
    STORY_3D_SETTLEMENT_SCHEMA_VERSION, STORY_3D_SETTLEMENT_ASSETS,
    story3DSettlementHash, story3DSettlementTier,
    story3DSettlementsCompile, story3DSettlementsValidate
};
