@echo off
setlocal
cd /d "%~dp0"
set "ELECTRON_RUN_AS_NODE="
echo.
echo   PIXEL RTS - 3D HIKAYE HARITASI TEKNIK DOGRULAMA
echo   Bu bir sanat-kalitesi demosu degildir.
echo   Simdilik arazi, kamera, LOD, politik katman ve akicilik test edilir.
echo.
call npm run start:3d
if errorlevel 1 (
  echo.
  echo   3D prototip baslatilamadi. Hata kodu: %errorlevel%
  pause
)
endlocal
