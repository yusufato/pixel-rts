# 3D harita — küçük oyuncu doğrulaması

`3D-HARITA-DOGRULA.bat` dosyasına çift tıkla ve normal biçimde yeni hikâye
kampanyası başlat. Bu turda şehir/araç/orman sanat kalitesini değerlendirme;
onlar henüz 3D kataloğa taşınmadı.

Şunları kontrol et:

1. Hikâye haritası açılınca sağ üstte `3D PROTOTİP` rozeti görünmeli.
2. Sol tuşla sürükleme kamerayı takılmadan hareket ettirmeli.
3. Tekerlekle imlecin gösterdiği yer korunarak yakınlaşıp uzaklaşmalı.
4. Rozette `NEAR / MID / FAR` değeri zoom ile değişmeli.
5. Orta/yakın görünümde kıyı halkası belirmeli; uzakta kapanmalı.
6. Politik renk katmanı varsayılan kapalı gelmeli; `P` tuşu açıp kapatmalı.
7. Şehir modeli, bina, araç ve bitki bekleme: bunlar sonraki 3D fazlarıdır.

Raporlarken çözünürlük, yaklaşık FPS ve şu dört kusuru ayrı yaz:

- kamera yönü veya zoom hissi;
- altıgen/kıyı hizası;
- okunabilirlik ve renkler;
- donma, geç belirme veya görüntü kaybı.

Beklenen teknik künye yaklaşık `154 HEX`, `6 DRAW`, `8.184 ÜÇGEN` ve
`READY_WORLD` durumudur. Sayılar LOD'a göre değişebilir; dünya/simülasyon
sonucu renderer yüzünden değişmemelidir.
